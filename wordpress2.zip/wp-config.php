<?php
define( 'WP_CACHE', true ); 
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */
// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'store' );
/** Database username */
define( 'DB_USER', 'root' );
/** Database password */
define( 'DB_PASSWORD', '' );
/** Database hostname */
define( 'DB_HOST', 'localhost' );
/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );
/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );
/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '-ok:r:BpHyrZ.YsIN*lzb KX<@gO9z}v4Lq4)tt&5bW-[[e,YO6=H >GX3OrJ?ll' );
define( 'SECURE_AUTH_KEY',  '*102<vOb3:BR,rY7J-CWeR+Hj(5jR{_K#M>=K7kjd!MGX)iz/nNx;O)0`h|C,cyn' );
define( 'LOGGED_IN_KEY',    'CkUXdx@XT u2D:[JD<^v}T9E]&).z4K3M&*BDmk.`nD-<56/j!JiPDV!}j2i.}xM' );
define( 'NONCE_KEY',        'MRukb*K1+vn(RP2bOKgRe,YT U@lXh/<+E(91=Bf,;Ag@<1=2TtMHoEN`S??b]yi' );
define( 'AUTH_SALT',        'Q$7L! L8mqc:x|_aQDkg-zVOL(&qdIv$f3yhWP7%F4*?rrv@rH&lV<3q?VpYyTR8' );
define( 'SECURE_AUTH_SALT', '1?1a8),Lqka>DYp3:b(C:51v3Fxrh41PO.aMkho5jTPDzyLGen#<USLc<,bub;Hv' );
define( 'LOGGED_IN_SALT',   ')iKOe>tiZ#3SW,)=#EI: :qjTXMX2lA_>o.<B!PnuLqRe:(RQ&gK&X;YQ!YYUCzy' );
define( 'NONCE_SALT',       'yyfOMq&OS3<s/lVdYko_}QP94H<Q+xDzxou/2p^27VQfi_{|x*l)VZNYoy}dqU-H' );
/**#@-*/
/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';
/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );
/* Add any custom values between this line and the "stop editing" line. */
/* That's all, stop editing! Happy publishing. */
/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}
/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';