<div <?php echo $model['field_attributes']; ?>>
    <?php echo $model['field_value']; ?>
</div>