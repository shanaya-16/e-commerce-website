<?php

namespace SW_WAPF\Includes\Models {

    if (!defined('ABSPATH')) {
        die;
    }

    class ConditionalRule
    {

        public $field;

        public $condition;

        public $value;

    }
}