a:2:{s:4:"body";s:142556:"<!DOCTYPE html>
<html lang="en-GB">
    <head>
	        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
        <style id="tb_inline_styles" data-no-optimize="1">.tb_animation_on{overflow-x:hidden}.themify_builder .wow{visibility:hidden;animation-fill-mode:both}[data-tf-animation]{will-change:transform,opacity,visibility}.themify_builder .tf_lax_done{transition-duration:.8s;transition-timing-function:cubic-bezier(.165,.84,.44,1)}[data-sticky-active].tb_sticky_scroll_active{z-index:1}[data-sticky-active].tb_sticky_scroll_active .hide-on-stick{display:none}@media(min-width:1025px){.hide-desktop{width:0!important;height:0!important;padding:0!important;visibility:hidden!important;margin:0!important;display:table-column!important;background:0!important}}@media(min-width:769px) and (max-width:1024px){.hide-tablet_landscape{width:0!important;height:0!important;padding:0!important;visibility:hidden!important;margin:0!important;display:table-column!important;background:0!important}}@media(min-width:601px) and (max-width:768px){.hide-tablet{width:0!important;height:0!important;padding:0!important;visibility:hidden!important;margin:0!important;display:table-column!important;background:0!important}}@media(max-width:600px){.hide-mobile{width:0!important;height:0!important;padding:0!important;visibility:hidden!important;margin:0!important;display:table-column!important;background:0!important}}@media(max-width:600px){
		    .themify_map.tf_map_loaded{width:100%!important}
		    .ui.builder_button,.ui.nav li a{padding:.525em 1.15em}
		    .fullheight>.row_inner:not(.tb_col_count_1){min-height:0}
	    }</style><noscript><style>.themify_builder .wow,.wow .tf_lazy{visibility:visible!important}</style></noscript>            <style id="tf_lazy_style" data-no-optimize="1">
                [data-tf-src]{
                    opacity:0
                }
                .tf_svg_lazy{
                    content-visibility:auto;
                    transition:filter .3s linear!important;filter:blur(25px);opacity:1;
                    transform:translateZ(0)
                }
                .tf_svg_lazy_loaded{
                    filter:blur(0)
                }
                .module[data-lazy],.module[data-lazy] .ui,.module_row[data-lazy]:not(.tb_first),.module_row[data-lazy]:not(.tb_first)>.row_inner,.module_row:not(.tb_first) .module_column[data-lazy],.module_row:not(.tb_first) .module_subrow[data-lazy],.module_subrow[data-lazy]>.subrow_inner{
                    background-image:none!important
                }
            </style>
            <noscript>
                <style>
                    [data-tf-src]{
                        display:none!important
                    }
                    .tf_svg_lazy{
                        filter:none!important;
                        opacity:1!important
                    }
                </style>
            </noscript>
                    <style id="tf_lazy_common" data-no-optimize="1">
                        img{
                max-width:100%;
                height:auto
            }
                                    .tf_fa{display:inline-block;width:1em;height:1em;stroke-width:0;stroke:currentColor;overflow:visible;fill:currentColor;pointer-events:none;vertical-align:middle;text-rendering:optimizeSpeed;buffered-rendering:static}#tf_svg symbol{overflow:visible}.tf_lazy{position:relative;visibility:visible;display:block;opacity:.3}.wow .tf_lazy{visibility:hidden;opacity:1;position:static;display:inline}div.tf_audio_lazy audio{visibility:hidden;height:0;display:inline}.mejs-container{visibility:visible}.tf_iframe_lazy{transition:opacity .3s ease-in-out;min-height:10px}.tf_carousel .tf_swiper-wrapper{display:flex}.tf_carousel .tf_swiper-slide{flex-shrink:0;opacity:0;width:100%;height:100%}.tf_carousel .tf_lazy{contain:none}.tf_swiper-wrapper>br,.tf_lazy.tf_swiper-wrapper .tf_lazy:after,.tf_lazy.tf_swiper-wrapper .tf_lazy:before{display:none}.tf_lazy:after,.tf_lazy:before{content:'';display:inline-block;position:absolute;width:10px!important;height:10px!important;margin:0 3px;top:50%!important;right:50%!important;left:auto!important;border-radius:100%;background-color:currentColor;visibility:visible;animation:tf-hrz-loader infinite .75s cubic-bezier(.2,.68,.18,1.08)}.tf_lazy:after{width:6px!important;height:6px!important;right:auto!important;left:50%!important;margin-top:3px;animation-delay:-.4s}@keyframes tf-hrz-loader{0%{transform:scale(1);opacity:1}50%{transform:scale(.1);opacity:.6}100%{transform:scale(1);opacity:1}}.tf_lazy_lightbox{position:fixed;background:rgba(11,11,11,.8);color:#ccc;top:0;left:0;display:flex;align-items:center;justify-content:center;z-index:999}.tf_lazy_lightbox .tf_lazy:after,.tf_lazy_lightbox .tf_lazy:before{background:#fff}.tf_vd_lazy,tf-lottie{display:flex;flex-wrap:wrap}tf-lottie{aspect-ratio:1.777}.tf_w.tf_vd_lazy video{width:100%;height:auto;position:static;object-fit:cover}
        </style>
        <title>ShopEase &#8211; Shop with Ease Anytime, Anywhere.</title>
<script type="text/template" id="tmpl-variation-template">
	<div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
	<div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
	<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
</script>
<script type="text/template" id="tmpl-unavailable-variation-template">
	<p>Sorry, this product is unavailable. Please choose a different combination.</p>
</script>
<meta name='robots' content='max-image-preview:large' />
<link rel="alternate" type="application/rss+xml" title="ShopEase &raquo; Feed" href="https://127.0.0.1/e_commerce_project/wordpress/feed/" />
<link rel="alternate" type="application/rss+xml" title="ShopEase &raquo; Comments Feed" href="https://127.0.0.1/e_commerce_project/wordpress/comments/feed/" />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-active-filters-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/add-to-cart-form.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-add-to-cart-form-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/add-to-cart-form.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/packages-style.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-packages-style-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/packages-style.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-products.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-all-products-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-products.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-reviews.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-all-reviews-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-reviews.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/attribute-filter.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-attribute-filter-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/attribute-filter.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/breadcrumbs.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-breadcrumbs-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/breadcrumbs.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/catalog-sorting.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-catalog-sorting-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/catalog-sorting.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/customer-account.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-customer-account-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/customer-account.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-category.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-featured-category-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-category.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-product.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-featured-product-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-product.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-mini-cart-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-price-filter-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-add-to-cart.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-add-to-cart-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-add-to-cart.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-button.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-button-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-button.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-categories.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-categories-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-categories.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-image-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image-gallery.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-image-gallery-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image-gallery.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-query.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-query-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-query.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-results-count.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-results-count-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-results-count.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-reviews.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-reviews-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-reviews.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sale-badge.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-sale-badge-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sale-badge.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-search.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-search-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-search.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sku.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-sku-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sku.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-stock-indicator.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-stock-indicator-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-stock-indicator.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-summary.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-summary-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-summary.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-title.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-title-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-title.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/rating-filter.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-rating-filter-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/rating-filter.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-category.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-reviews-by-category-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-category.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-product.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-reviews-by-product-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-product.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-details.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-product-details-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-details.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/single-product.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-single-product-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/single-product.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/stock-filter.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-stock-filter-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/stock-filter.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-cart-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-checkout-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout.css?ver=10.6.5' media='all' />
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents.css?ver=10.6.5" as="style"><link rel='stylesheet' id='wc-blocks-style-mini-cart-contents-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents.css?ver=10.6.5' media='all' />
<style id='classic-theme-styles-inline-css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/advanced-product-fields-for-woocommerce/assets/css/frontend.min.css?ver=1.6.3" as="style"><link rel='stylesheet' id='wapf-frontend-css-css' href='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/advanced-product-fields-for-woocommerce/assets/css/frontend.min.css?ver=1.6.3' media='all' />
<style id='woocommerce-inline-inline-css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<script src='https://127.0.0.1/e_commerce_project/wordpress/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2' id='wp-polyfill-inert-js'></script>
<script src='https://127.0.0.1/e_commerce_project/wordpress/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.11' id='regenerator-runtime-js'></script>
<script src='https://127.0.0.1/e_commerce_project/wordpress/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script src='https://127.0.0.1/e_commerce_project/wordpress/wp-includes/js/dist/hooks.min.js?ver=c6aec9a8d4e5a5d543a1' id='wp-hooks-js'></script>
<script src='https://stats.wp.com/w.js?ver=202332' id='woo-tracks-js'></script>
<script src='https://127.0.0.1/e_commerce_project/wordpress/wp-includes/js/jquery/jquery.min.js?ver=3.7.0' id='jquery-core-js'></script>
<link rel="https://api.w.org/" href="https://127.0.0.1/e_commerce_project/wordpress/wp-json/" /><link rel="alternate" type="application/json" href="https://127.0.0.1/e_commerce_project/wordpress/wp-json/wp/v2/pages/25" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://127.0.0.1/e_commerce_project/wordpress/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.3" />
<meta name="generator" content="WooCommerce 8.0.1" />
<link rel="canonical" href="https://127.0.0.1/e_commerce_project/wordpress/" />
<link rel='shortlink' href='https://127.0.0.1/e_commerce_project/wordpress/' />
<link rel="alternate" type="application/json+oembed" href="https://127.0.0.1/e_commerce_project/wordpress/wp-json/oembed/1.0/embed?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://127.0.0.1/e_commerce_project/wordpress/wp-json/oembed/1.0/embed?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2F&#038;format=xml" />
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<link rel="prefetch" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/themes/themify-shoppe/js/themify.script.js?ver=7.2.5" as="script" fetchpriority="low"><link rel="prefetch" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/themes/themify-shoppe/themify/js/modules/themify.sidemenu.js?ver=7.2.3" as="script" fetchpriority="low"><link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/themes/themify-shoppe/js/modules/themify.shop.js?ver=7.2.5" as="script" fetchpriority="low"><link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/themes/themify-shoppe/themify/themify-builder/js/themify.builder.script.js?ver=7.2.3" as="script" fetchpriority="low"><link rel="preload" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/Category-Jungle-Leggings-80.jpg" as="image" fetchpriority="high"><style id="tf_gf_fonts_style">@font-face{font-family:'Frank Ruhl Libre';src:url(https://fonts.gstatic.com/s/frankruhllibre/v20/j8_w6_fAw7jrcalD7oKYNX0QfAnPW7Ll4ajn.woff2) format('woff2');unicode-range:U+0590-05FF,U+200C-2010,U+20AA,U+25CC,U+FB1D-FB4F;}@font-face{font-family:'Frank Ruhl Libre';src:url(https://fonts.gstatic.com/s/frankruhllibre/v20/j8_w6_fAw7jrcalD7oKYNX0QfAnPW77l4ajn.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Frank Ruhl Libre';src:url(https://fonts.gstatic.com/s/frankruhllibre/v20/j8_w6_fAw7jrcalD7oKYNX0QfAnPW7Dl4Q.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Frank Ruhl Libre';font-weight:500;src:url(https://fonts.gstatic.com/s/frankruhllibre/v20/j8_w6_fAw7jrcalD7oKYNX0QfAnPW7Ll4ajn.woff2) format('woff2');unicode-range:U+0590-05FF,U+200C-2010,U+20AA,U+25CC,U+FB1D-FB4F;}@font-face{font-family:'Frank Ruhl Libre';font-weight:500;src:url(https://fonts.gstatic.com/s/frankruhllibre/v20/j8_w6_fAw7jrcalD7oKYNX0QfAnPW77l4ajn.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Frank Ruhl Libre';font-weight:500;src:url(https://fonts.gstatic.com/s/frankruhllibre/v20/j8_w6_fAw7jrcalD7oKYNX0QfAnPW7Dl4Q.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Frank Ruhl Libre';font-weight:700;src:url(https://fonts.gstatic.com/s/frankruhllibre/v20/j8_w6_fAw7jrcalD7oKYNX0QfAnPW7Ll4ajn.woff2) format('woff2');unicode-range:U+0590-05FF,U+200C-2010,U+20AA,U+25CC,U+FB1D-FB4F;}@font-face{font-family:'Frank Ruhl Libre';font-weight:700;src:url(https://fonts.gstatic.com/s/frankruhllibre/v20/j8_w6_fAw7jrcalD7oKYNX0QfAnPW77l4ajn.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Frank Ruhl Libre';font-weight:700;src:url(https://fonts.gstatic.com/s/frankruhllibre/v20/j8_w6_fAw7jrcalD7oKYNX0QfAnPW7Dl4Q.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:300;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zoTjmbI.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:300;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zsTjmbI.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:300;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zUTjg.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Libre Franklin';font-style:italic;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zoTjmbI.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Libre Franklin';font-style:italic;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zsTjmbI.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Libre Franklin';font-style:italic;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zUTjg.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:500;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zoTjmbI.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:500;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zsTjmbI.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:500;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zUTjg.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:600;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zoTjmbI.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:600;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zsTjmbI.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:600;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zUTjg.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:700;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zoTjmbI.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:700;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zsTjmbI.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Libre Franklin';font-style:italic;font-weight:700;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizBREVItHgc8qDIbSTKq4XkRiUa6zUTjg.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Libre Franklin';font-weight:300;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUQ2zcLig.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Libre Franklin';font-weight:300;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUR2zcLig.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Libre Franklin';font-weight:300;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUf2zc.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Libre Franklin';src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUQ2zcLig.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Libre Franklin';src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUR2zcLig.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Libre Franklin';src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUf2zc.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Libre Franklin';font-weight:500;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUQ2zcLig.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Libre Franklin';font-weight:500;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUR2zcLig.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Libre Franklin';font-weight:500;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUf2zc.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Libre Franklin';font-weight:600;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUQ2zcLig.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Libre Franklin';font-weight:600;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUR2zcLig.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Libre Franklin';font-weight:600;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUf2zc.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Libre Franklin';font-weight:700;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUQ2zcLig.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Libre Franklin';font-weight:700;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUR2zcLig.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Libre Franklin';font-weight:700;src:url(https://fonts.gstatic.com/s/librefranklin/v13/jizDREVItHgc8qDIbSTKq4XkRiUf2zc.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Montserrat';font-style:italic;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUQjIg1_i6t8kCHKm459WxRxC7mw9c.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Montserrat';font-style:italic;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUQjIg1_i6t8kCHKm459WxRzS7mw9c.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Montserrat';font-style:italic;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUQjIg1_i6t8kCHKm459WxRxi7mw9c.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Montserrat';font-style:italic;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUQjIg1_i6t8kCHKm459WxRxy7mw9c.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Montserrat';font-style:italic;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUQjIg1_i6t8kCHKm459WxRyS7m.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Montserrat';font-style:italic;font-weight:700;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUQjIg1_i6t8kCHKm459WxRxC7mw9c.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Montserrat';font-style:italic;font-weight:700;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUQjIg1_i6t8kCHKm459WxRzS7mw9c.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Montserrat';font-style:italic;font-weight:700;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUQjIg1_i6t8kCHKm459WxRxi7mw9c.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Montserrat';font-style:italic;font-weight:700;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUQjIg1_i6t8kCHKm459WxRxy7mw9c.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Montserrat';font-style:italic;font-weight:700;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUQjIg1_i6t8kCHKm459WxRyS7m.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Montserrat';font-weight:300;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459WRhyzbi.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Montserrat';font-weight:300;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459W1hyzbi.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Montserrat';font-weight:300;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459WZhyzbi.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Montserrat';font-weight:300;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459Wdhyzbi.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Montserrat';font-weight:300;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459Wlhyw.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Montserrat';src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459WRhyzbi.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Montserrat';src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459W1hyzbi.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Montserrat';src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459WZhyzbi.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Montserrat';src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459Wdhyzbi.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Montserrat';src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459Wlhyw.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Montserrat';font-weight:600;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459WRhyzbi.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Montserrat';font-weight:600;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459W1hyzbi.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Montserrat';font-weight:600;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459WZhyzbi.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Montserrat';font-weight:600;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459Wdhyzbi.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Montserrat';font-weight:600;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459Wlhyw.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Montserrat';font-weight:700;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459WRhyzbi.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Montserrat';font-weight:700;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459W1hyzbi.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Montserrat';font-weight:700;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459WZhyzbi.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Montserrat';font-weight:700;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459Wdhyzbi.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Montserrat';font-weight:700;src:url(https://fonts.gstatic.com/s/montserrat/v25/JTUSjIg1_i6t8kCHKm459Wlhyw.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}</style><link rel="preload" fetchpriority="high" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/themify-concate/940133474/themify-852419926.min.css" as="style"><link fetchpriority="high" id="themify_concate-css" rel="stylesheet" href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/themify-concate/940133474/themify-852419926.min.css">    </head>
    <body class="home page-template-default page page-id-25 page-parent theme-themify-shoppe skin-furniture sidebar-none full_width woocommerce-js woo_qty_btn tb_animation_on header-logo-left cart-style-dropdown wc-cart-empty fixed-header-enabled footer-right-column filter-hover-none filter-featured-only">

	<a class="screen-reader-text skip-to-content" href="#content">Skip to content</a><!-- hook content: themify_body_start --><div class="tb_layout_part_wrap tf_w">
<!--themify_builder_content-->
    <div  class="themify_builder_content themify_builder_content-335 themify_builder not_editable_builder" data-postid="335">
        			<!-- module_row -->
	<div  data-lazy="1" class="module_row themify_builder_row tb_tyg3258 tb_first tf_w tf_clearfix">
	    			<div class="row_inner col_align_top tb_col_count_1 tf_box tf_rel">
		            <div  data-lazy="1" class="module_column tb-column col-full tb_ryhi260 first">
                                                        <div class="tb-column-inner tf_box tf_w">
                        <!-- module text -->
<div  class="module module-text tb_hkhg418   " data-lazy="1">
        <div  class="tb_text_wrap">
    <p style="text-align: center;">Free shipping for orders over 90$</p>    </div>
</div>
<!-- /module text -->                    </div><!-- .tb-column-inner -->
                            </div><!-- .module_column -->
            	    </div><!-- .row_inner -->
	</div><!-- .module_row -->
	    </div>
<!--/themify_builder_content-->
</div>
<!-- /hook content: themify_body_start --><svg id="tf_svg" style="display:none"><defs><symbol id="tf-ti-search" viewBox="0 0 32 32"><path d="m31.25 29.875-1.313 1.313-9.75-9.75a12.019 12.019 0 0 1-7.938 3c-6.75 0-12.25-5.5-12.25-12.25 0-3.25 1.25-6.375 3.563-8.688C5.875 1.25 8.937-.063 12.25-.063c6.75 0 12.25 5.5 12.25 12.25 0 3-1.125 5.813-3 7.938zm-19-7.312c5.688 0 10.313-4.688 10.313-10.375S17.938 1.813 12.25 1.813c-2.813 0-5.375 1.125-7.313 3.063-2 1.938-3.063 4.563-3.063 7.313 0 5.688 4.625 10.375 10.375 10.375z"/></symbol><symbol id="tf-ti-shopping-cart" viewBox="0 0 32 32"><path d="M5.19 23.5C7 23.5 8.5 25 8.5 26.81S7 30.13 5.2 30.13s-3.32-1.5-3.32-3.32 1.5-3.31 3.32-3.31zm0 4.75a1.4 1.4 0 0 0 1.37-1.44c0-.75-.62-1.37-1.37-1.37a1.4 1.4 0 0 0-1.44 1.37c0 .82.63 1.44 1.44 1.44zm16-4.75c1.81 0 3.31 1.5 3.31 3.31s-1.5 3.32-3.31 3.32-3.32-1.5-3.32-3.32 1.5-3.31 3.32-3.31zm0 4.75a1.4 1.4 0 0 0 1.37-1.44c0-.75-.62-1.37-1.37-1.37a1.4 1.4 0 0 0-1.44 1.37c0 .82.63 1.44 1.44 1.44zm4-24.5H32v1.88h-5.19l-.5 3-1.93 14H1.93L-.13 7.5h24.75zm-.88 5.69H2l.31 1.87h21.75zM3.63 20.75h19.12l1.06-7.56H2.56z"/></symbol><symbol id="tf-ti-user" viewBox="0 0 32 32"><path d="M32 31.06V32H0v-.94c.13-5.12 5.31-9.5 12.44-10.62v-2.38a9.45 9.45 0 0 1-2.19-3.75 3.57 3.57 0 0 1-1.44-1.69c-.62-1.37-.44-2.68.38-3.25-.07-.37-.07-.8-.07-1.18v-.7c-.06-2.12-.06-4.8 3.13-5.12 0 0 .12-.12.19-.25.5-1 1.25-2 3.69-2.12h.5c3.56 0 6 1.31 6.8 3.69.26.68 0 1.31-.18 1.81a4.8 4.8 0 0 0-.38 2.56c.07.44 0 .94 0 1.38.63.56.82 1.75.38 3.06a3.27 3.27 0 0 1-1.5 1.94 9.95 9.95 0 0 1-2 3.44v2.62c7 1.13 12.13 5.5 12.25 10.56zm-30-.93h28c-.69-3.88-5.31-7.13-11.31-7.88l-.88-.13V17l.38-.31c.68-.5 1.37-1.7 1.93-3.32l.2-.62H21c0-.06.25-.31.44-.88.12-.37.19-.68.19-.87l-.88.06.19-1.5c.06-.44.12-.94.06-1.25a6.3 6.3 0 0 1 .5-3.5c.07-.19.13-.44.13-.5-.69-2.12-3.44-2.44-5-2.44h-.44c-1.56.07-1.81.57-2.06 1.13-.25.44-.63 1.19-1.7 1.25-1.37.12-1.5.69-1.43 3.19v.75c0 .56.06 1.19.13 1.81l.18 1.38-1-.25c.07.18.13.43.25.75.2.56.5.8.63.8l.56.13.13.5c.56 1.7 1.31 3 2.06 3.5l.37.25v5.07l-.8.06c-6.13.75-10.76 4-11.5 7.94z"/></symbol><symbol id="tf-ti-heart" viewBox="0 0 32 32"><path d="M23.5 1.25a8.5 8.5 0 0 1 8.25 10.5l-.25.69C29.62 20 17.12 30.13 16.56 30.56L16 31l-.56-.44C14.94 30.13 3.19 20.7.5 12.5l-.19-.69A6.74 6.74 0 0 1 0 9.7a8.5 8.5 0 0 1 8.5-8.44A8.54 8.54 0 0 1 16 5.81a8.54 8.54 0 0 1 7.5-4.56zm6.44 10a6.58 6.58 0 0 0-6.44-8.13 6.56 6.56 0 0 0-6.56 6.57v.5h-1.88v-.5A6.56 6.56 0 0 0 8.5 3.12 6.58 6.58 0 0 0 1.87 9.7c0 .5.07 1 .25 1.62l.2.56C4.5 18.57 13.55 26.57 16 28.64c2.5-2.13 12.19-10.57 13.69-16.7z"/></symbol><symbol id="tf-ti-zoom-in" viewBox="0 0 32 32"><path d="m31.25 29.94-1.31 1.31-9.75-9.75a12 12 0 0 1-7.94 3A12.27 12.27 0 0 1 3.56 3.56a12.27 12.27 0 0 1 20.94 8.69c0 3-1.13 5.81-3 7.94zm-19-7.38a10.34 10.34 0 0 0 0-20.69 10 10 0 0 0-7.31 3.07 10 10 0 0 0-3.07 7.31c0 5.69 4.63 10.31 10.38 10.31zm.94-11.25V7.5H11.3v3.81H7.5v1.88h3.81v3.75h1.88v-3.75h3.75V11.3h-3.75z"/></symbol><symbol id="tf-ti-export" viewBox="0 0 32 32"><path d="m8.2 11.2 6.9-7v20.2h1.8V4.1l7 7.1L25 9.9 16 .5 6.9 9.9zm22 5.8H32v12.2a2.8 2.8 0 0 1-2.8 2.8H2.8A2.8 2.8 0 0 1 0 29.2V17h1.9v12.2c0 .5.4 1 1 1h26.3c.5 0 1-.5 1-1V17z"/></symbol><symbol id="tf-ti-twitter-alt" viewBox="0 0 32 32"><path d="M28.7 9.5A13.3 13.3 0 0 0 32 6.1a12.9 12.9 0 0 1-3.8 1 6.9 6.9 0 0 0 3-3.6 12 12 0 0 1-4.3 1.6 6.6 6.6 0 0 0-11.3 4.5c0 .5 0 1 .2 1.5A18.4 18.4 0 0 1 2.2 4.2a6.8 6.8 0 0 0-.9 3.3 6.6 6.6 0 0 0 3 5.5 6.7 6.7 0 0 1-3-.9v.2a6.6 6.6 0 0 0 5.3 6.4 7.9 7.9 0 0 1-1.8.2l-1.2-.1a6.5 6.5 0 0 0 6.2 4.5 13 13 0 0 1-8.2 2.8H0A18.4 18.4 0 0 0 10 29c12.1 0 18.8-10 18.8-18.7l-.1-.8z"/></symbol><symbol id="tf-ti-facebook" viewBox="0 0 32 32"><path d="M23.44 10.5h-5V7.75c0-1.44.19-2.25 2.25-2.25h2.75V0H19c-5.31 0-7.13 2.69-7.13 7.19v3.31h-3.3V16h3.3v16h6.57V16h4.44z"/></symbol><symbol id="tf-ti-pinterest" viewBox="0 0 32 32"><path d="M28.31 11.69c0-5.38-4.62-10.44-11.62-10.44C8 1.25 3.62 7.5 3.62 12.69c0 3.12 1.25 5.94 3.75 7 .44.12.82 0 .94-.5.07-.31.25-1.13.38-1.44.12-.5.06-.62-.25-1a5.4 5.4 0 0 1-1.25-3.62c0-4.63 3.44-8.75 9-8.75 4.94 0 7.62 3 7.62 7 0 5.25-2.31 9.75-5.81 9.75a2.88 2.88 0 0 1-2.87-3.57c.56-2.31 1.62-4.81 1.62-6.44 0-1.5-.81-2.8-2.5-2.8-1.94 0-3.5 2.05-3.5 4.74 0 0 0 1.75.56 2.94-2 8.44-2.31 9.94-2.31 9.94a13.85 13.85 0 0 0-.31 4.18s.18 2.2 2.12.75c.69-1.06 1.5-2.5 1.88-3.87 0 0 .18-.81 1.25-5 .62 1.19 2.5 2.25 4.5 2.25 5.87 0 9.87-5.31 9.87-12.56z"/></symbol><symbol id="tf-ti-linkedin" viewBox="0 0 32 32"><path d="M1.3 11v19.4h6.5V10.9H1.3zm3.3-9.4c2.2 0 3.6 1.5 3.6 3.3S6.8 8.3 4.6 8.3h-.1C2.3 8.3.9 6.8.9 5s1.5-3.3 3.7-3.3zm19 8.9c4.3 0 7.5 2.8 7.5 8.7v11.2h-6.5V20c0-2.6-1-4.4-3.3-4.4-1.7 0-2.8 1.2-3.3 2.3l-.2 1.7v10.8h-6.4V10.9h6.4v2.9a6.3 6.3 0 0 1 5.8-3.3z"/></symbol><symbol id="tf-ti-twitter" viewBox="0 0 32 32"><path d="M32 6c-.9 1.4-2 2.6-3.3 3.5v.8C28.8 19 22.1 29 10.1 29A18.5 18.5 0 0 1 0 26l1.6.1a13 13 0 0 0 8.1-2.8 6.5 6.5 0 0 1-6-4.6l1.1.2a7.9 7.9 0 0 0 1.8-.2 6.6 6.6 0 0 1-5.3-6.5c.9.4 1.9.7 3 .8a6.6 6.6 0 0 1-3-5.5c0-1.2.4-2.3 1-3.3 3.1 4 8 6.6 13.4 6.9V9.6A6.5 6.5 0 0 1 22 3a6.6 6.6 0 0 1 5 2c1.5-.2 3-.7 4.2-1.5a6.9 6.9 0 0 1-2.9 3.6c1.4-.2 2.6-.5 3.8-1zm-5.1 4.3v-.7c0-.4 0-.7.2-1-.3-.2-.5-.5-.7-1a1.2 1.2 0 0 1 0-.7 2.2 2.2 0 0 1-.8-.5A4.7 4.7 0 0 0 22 4.9a4.7 4.7 0 0 0-4.6 4.7l.1 1c0 .6 0 1.3-.4 1.7a2 2 0 0 1-1.4.6h-.1c-4.6-.2-9-2-12.4-5a4.7 4.7 0 0 0 2 3.5c.7.5 1 1.3.8 2.2a2 2 0 0 1-1.8 1.3H4a4.8 4.8 0 0 0 3 2c.8.1 1.4.9 1.4 1.7S8 20.2 7 20.5a4.7 4.7 0 0 0 2.8 1 1.9 1.9 0 0 1 1 3.3 13.6 13.6 0 0 1-3.5 2c1 .3 1.8.3 2.8.3 11.5 0 16.8-9.8 16.8-16.8z"/></symbol><symbol id="tf-ti-instagram" viewBox="0 0 32 32"><path d="M24.5 0C28.63 0 32 3.38 32 7.5v17c0 4.13-3.38 7.5-7.5 7.5h-17A7.52 7.52 0 0 1 0 24.5v-17C0 3.37 3.38 0 7.5 0h17zm5.63 24.5V13.19h-6.07c.57 1.12.88 2.37.88 3.75a8.94 8.94 0 1 1-17.88 0c0-1.38.31-2.63.88-3.75H1.87V24.5a5.68 5.68 0 0 0 5.63 5.63h17a5.68 5.68 0 0 0 5.62-5.63zm-7.07-7.56c0-3.88-3.19-7.07-7.06-7.07s-7.06 3.2-7.06 7.07S12.13 24 16 24s7.06-3.19 7.06-7.06zm-.18-5.63h7.25V7.5a5.68 5.68 0 0 0-5.63-5.63h-17A5.68 5.68 0 0 0 1.87 7.5v3.81h7.25C10.75 9.31 13.25 8 16 8s5.25 1.31 6.88 3.31zm4.3-6.19c0-.56-.43-1-1-1h-2.56c-.56 0-1.06.44-1.06 1v2.44c0 .57.5 1 1.07 1h2.56c.56 0 1-.44 1-1V5.13z"/></symbol><symbol id="tf-fab-twitter" viewBox="0 0 32 32"><path d="M28.69 9.5q.06.25.06.81 0 3.32-1.25 6.6t-3.53 6-5.9 4.4-8 1.7Q4.56 29 0 26.05q.69.07 1.56.07 4.57 0 8.2-2.82-2.2 0-3.85-1.28T3.63 18.8q.62.07 1.19.07.87 0 1.75-.2-1.5-.3-2.7-1.24T2 15.16t-.69-2.9v-.13q1.38.8 2.94.87-2.94-2-2.94-5.5 0-1.75.94-3.31Q4.7 7.25 8.22 9.06t7.53 2q-.12-.75-.12-1.5 0-2.69 1.9-4.62T22.13 3Q25 3 26.94 5.06q2.25-.43 4.19-1.56-.75 2.31-2.88 3.63 1.88-.25 3.75-1.07-1.37 2-3.31 3.44z"/></symbol><symbol id="tf-fab-facebook" viewBox="0 0 17 32"><path d="M13.5 5.31q-1.13 0-1.78.38t-.85.94-.18 1.43V12H16l-.75 5.69h-4.56V32H4.8V17.7H0V12h4.8V7.5q0-3.56 2-5.53T12.13 0q2.68 0 4.37.25v5.06h-3z"/></symbol><symbol id="tf-fab-youtube" viewBox="0 0 36 32"><path d="M34.38 7.75q.18.75.34 1.88t.22 2.21.1 2.03.02 1.57V16q0 5.63-.68 8.31-.32 1.07-1.13 1.88t-1.94 1.12q-1.19.32-4.5.47t-6.06.22H18q-10.7 0-13.31-.69-2.44-.68-3.07-3-.31-1.18-.47-3.28T.94 17.5V16q0-5.56.68-8.25.32-1.12 1.13-1.94T4.69 4.7q1.18-.31 4.5-.47T15.25 4H18q10.69 0 13.31.69 1.13.31 1.94 1.12t1.13 1.94zM14.5 21.13 23.44 16l-8.94-5.06v10.19z"/></symbol><style id="tf_fonts_style">.tf_fa.tf-fab-youtube{width:1.125em}</style></defs></svg><script> </script><div class="tf_search_form tf_search_overlay" data-lazy="1">
<form role="search" method="get" id="searchform" class="tf_rel tf_hide" action="https://127.0.0.1/e_commerce_project/wordpress/">

	<div class="tf_icon_wrap icon-search"><svg  aria-label="Search" class="tf_fa tf-ti-search" role="img"><use href="#tf-ti-search"></use></svg></div>

	<input type="text" name="s" id="s" title="Search" placeholder="Search" value="" />

	
</form>
</div>
	<div id="pagewrap" class="tf_box hfeed site">
        
		    	    <div id="headerwrap"  class=' tf_box tf_w'>
		    <div class="top-bar-widgets tf_box">
	<div class="top-bar-widget-inner pagewidth tf_box tf_clearfix">
		<div class="top-bar-left tf_left tf_textl">
					</div>
		<div class="top-bar-right tf_right tf_textr">
					</div>
		<!-- /.top-bar-widget-inner -->
	</div>
</div>
<!-- /.top-bar-widget -->    		<!-- /Top bar widgets -->

		    
    		<header id="header" class="pagewidth tf_box tf_rel tf_clearfix" itemscope="itemscope" itemtype="https://schema.org/WPHeader">

			
						    				<div id="cart-link-mobile" class="tf_hide tf_text_dec">
				    <a  class="icon-menu tf_right" href="javascript:;">
					<em class="icon-shopping-cart">
					    <svg  aria-label="Shopping Cart" class="tf_fa tf-ti-shopping-cart" role="img"><use href="#tf-ti-shopping-cart"></use></svg>					</em>
					<span class="icon-menu-count cart_empty">0</span>
				    </a>
				    
<div class="shopdock">
		<div class="tf_textc empty-shopdock">Your cart is empty. Go to <a href="https://127.0.0.1/e_commerce_project/wordpress/?page_id=6">Shop</a>.</div>	
	</div>
				</div>
			    			    <a id="menu-icon" class="tf_text_dec tf_box" href="#mobile-menu"><span class="menu-icon-inner tf_vmiddle tf_inline_b tf_rel tf_box"></span><span class="screen-reader-text">Menu</span></a>
			
    		    <div class="logo-wrap tf_inline_b tf_rel">
			    <div id="site-logo"><a href="https://127.0.0.1/e_commerce_project/wordpress" title="ShopEase"><span>ShopEase</span></a></div><div id="site-description" class="site-description"><span>Shop with Ease Anytime, Anywhere.</span></div>    		    </div>
								
			<div id="mobile-menu" class="sidemenu sidemenu-off tf_scrollbar">
			    			    <div class="header-icons">
    <div class="top-icon-wrap">
	<ul id="icon-menu" class="icon-menu"><li id="menu-item-48" class="menu-item-page-46 menu-item menu-item-type-post_type menu-item-object-page menu-item-48"><a href="https://127.0.0.1/e_commerce_project/wordpress/my-account/"><em><svg  class="tf_fa tf-ti-user" aria-hidden="true"><use href="#tf-ti-user"></use></svg></em><span class="tooltip">My Account</span></a></li>
</ul>
			<ul class="icon-menu">

			
											<li class="wishlist">
					<a class="tools_button" href="https://127.0.0.1/e_commerce_project/wordpress/wishlist/">
					<em class="icon-heart"><svg  aria-label="Whishlist" class="tf_fa tf-ti-heart" role="img"><use href="#tf-ti-heart"></use></svg></em>
					<span class="icon-menu-count wishlist_empty"></span>
					<span class="tooltip">Wishlist</span>
					</a>
				</li>
																<li id="cart-icon-count" class="cart empty-cart">
					<a  href="javascript:;">
					<em class="icon-shopping-cart"><svg  aria-label="Shopping Cart" class="tf_fa tf-ti-shopping-cart" role="img"><use href="#tf-ti-shopping-cart"></use></svg></em>
					<span class="icon-menu-count cart_empty">0</span>
					<span class="tooltip">Cart</span>
					</a>
					
<div class="shopdock">
		<div class="tf_textc empty-shopdock">Your cart is empty. Go to <a href="https://127.0.0.1/e_commerce_project/wordpress/?page_id=6">Shop</a>.</div>	
	</div>

				</li>
							
	    </ul><!-- .icon-menu -->
	
    </div>
            <a data-lazy="1" class="search-button tf_search_icon tf_box" href="#"><svg  aria-label="Search" class="tf_fa tf-ti-search" role="img"><use href="#tf-ti-search"></use></svg><span class="screen-reader-text">Search</span></a>
        <!-- /search-button -->
    </div>
                                                <nav id="main-nav-wrap" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">
                    <ul id="main-nav" class="main-nav tf_clearfix tf_box"><li class="menu-item-page-216 menu-item menu-item-type-post_type menu-item-object-page menu-item-218" ><a  href="https://127.0.0.1/e_commerce_project/wordpress/shop-2/">Shop</a> </li>
<li class="menu-item-page-31 menu-item menu-item-type-post_type menu-item-object-page menu-item-43" ><a  href="https://127.0.0.1/e_commerce_project/wordpress/contact/">Contact</a> </li>
<li class="menu-item-product_cat-15 menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children mega has-mega-sub-menu has-mega has-sub-menu mega-link menu-item-255" data-termid="15" data-tax="product_cat" aria-haspopup="true"><a  href="https://127.0.0.1/e_commerce_project/wordpress/product-category/essentials/">Essentials<span class="child-arrow"></span></a> <div class="mega-sub-menu sub-menu"><ul class="tf_mega_taxes tf_left tf_box"><li class="menu-item-product_cat-34 menu-item menu-item-type-taxonomy menu-item-object-product_cat mega-sub-item mega-link menu-item-258 menu-product_cat-34-parent-255" data-termid="34" data-tax="product_cat"><a  href="https://127.0.0.1/e_commerce_project/wordpress/product-category/rings/">Rings</a> </li>
<li class="menu-item-product_cat-23 menu-item menu-item-type-taxonomy menu-item-object-product_cat mega-sub-item mega-link menu-item-259 menu-product_cat-23-parent-255" data-termid="23" data-tax="product_cat"><a  href="https://127.0.0.1/e_commerce_project/wordpress/product-category/watches/">watches</a> </li>
<li class="menu-item-product_cat-22 menu-item menu-item-type-taxonomy menu-item-object-product_cat mega-sub-item mega-link menu-item-257 menu-product_cat-22-parent-255" data-termid="22" data-tax="product_cat"><a  href="https://127.0.0.1/e_commerce_project/wordpress/product-category/leather-goods/backpacks/">Backpacks</a> </li>
</ul></div></li>
<li class="menu-item-product_cat-21 menu-item menu-item-type-taxonomy menu-item-object-product_cat mega-link menu-item-256" data-termid="21" data-tax="product_cat"><a  href="https://127.0.0.1/e_commerce_project/wordpress/product-category/leather-goods/">Leather goods</a> </li>
</ul>                    <!-- /#main-nav -->
                </nav>
                                <a id="menu-icon-close" class="tf_hide tf_text_dec tf_close" aria-label="Close menu" href="#mobile-menu"><span class="screen-reader-text">Close Menu</span></a>

                			    			</div>
			    		    <!-- /#mobile-menu -->

			
			
    		</header>
    		<!-- /#header -->

		    
    	    </div>
	    	    <!-- /#headerwrap -->

	    <div id="body" class="tf_clear tf_box tf_mw tf_clearfix">
		
<!-- layout-container -->
<div id="layout" class="pagewidth tf_box tf_clearfix">
        <!-- content -->
    <main id="content" class="tf_left tf_box tf_clearfix">
					<div id="page-25" class="type-page">
						<div class="page-content entry-content">
	    <!--themify_builder_content-->
<div id="themify_builder_content-25" data-postid="25" class="themify_builder_content themify_builder_content-25 themify_builder tf_clear">
    			<!-- module_row -->
	<div  data-lazy="1" class="module_row themify_builder_row tb_2jrz785 tf_w tf_clearfix">
	    <div class="builder_row_cover tf_abs"></div>			<div class="row_inner col_align_top tb_col_count_1 tf_box tf_rel">
		            <div  data-lazy="1" class="module_column tb-column col-full tb_bpik785 first">
                                                        <div class="tb-column-inner tf_box tf_w">
                        <!-- module text -->
<div  class="module module-text tb_mgsc137  repeat " data-lazy="1">
        <div  class="tb_text_wrap">
    <h2>Luxury Travel Suitcases</h2>    </div>
</div>
<!-- /module text --><!-- module text -->
<div  class="module module-text tb_j20p369   " data-lazy="1">
        <div  class="tb_text_wrap">
    <p>Refined , Stylish ,Practical</p>    </div>
</div>
<!-- /module text --><!-- module buttons -->
<div  class="module module-buttons tb_4vm9638 buttons-horizontal solid " data-lazy="1">
    	<div class="module-buttons-item tf_inline_b">
							<a href="http://127.0.0.1/e_commerce_project/wordpress/shop/" class="ui builder_button black" >
											<span class="tf_inline_b tf_vmiddle">Shop now</span>
											</a>
			    	</div>
    </div>
<!-- /module buttons -->
                    </div><!-- .tb-column-inner -->
                            </div><!-- .module_column -->
            	    </div><!-- .row_inner -->
	</div><!-- .module_row -->
				<!-- module_row -->
	<div  data-lazy="1" class="module_row themify_builder_row tb_ridc828 tf_w tf_clearfix">
	    			<div class="row_inner col_align_top tb_col_count_1 tf_box tf_rel">
		            <div  data-lazy="1" class="module_column tb-column col-full tb_fm3u828 first">
                                                        <div class="tb-column-inner tf_box tf_w">
                        <!-- module text -->
<div  class="module module-text tb_nbch829   " data-lazy="1">
        <div  class="tb_text_wrap">
    <h4 style="text-align: center;">Best Sellers</h4>
<h2 style="text-align: center;">Featured Products</h2>    </div>
</div>
<!-- /module text -->
	<div  id="tb_mntk186" class="module woocommerce module-products tb_mntk186 " data-lazy="1">
					<ul  class="loops-wrapper products wc-products grid3 tf_clearfix" data-lazy="1">
													<li class="post has-post-title has-post-date no-post-category no-post-tag has-post-comment has-post-author product type-product post-229 status-publish instock product_cat-essentials has-post-thumbnail sale featured shipping-taxable purchasable product-type-simple">
															
																										<figure class="post-image">
    	    
	<span class="onsale">Sale!</span>
	            	<a href="https://127.0.0.1/e_commerce_project/wordpress/product/leggings/" title="Leggings"><img data-tf-not-load="1" fetchpriority="high" loading="auto" decoding="sync" decoding="async" src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/Category-Jungle-Leggings-80.jpg" class="wp-post-image wp-image-190" title="Category-Jungle-Leggings-80" alt="Category-Jungle-Leggings-80"></a>
    </figure>																	
								<div class="post-content">
										    <div class="product-content">
		    <div class="product-content-inner-wrapper">
			    <div class="product-content-inner">
	    									
																																						<h3 class="product_title">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/leggings/" title="Leggings">
												
												Leggings
																								</a>
																					</h3>
																			  

									
	<span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>99.00</bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>79.00</bdi></span></ins></span>
<p class="add-to-cart-button"><a href="?add-to-cart=229" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="229" data-product_sku="" aria-label="Add &ldquo;Leggings&rdquo; to your basket" aria-describedby="" rel="nofollow">Add to basket</a></p>		<div class="product-share-wrap tf_inline_b tf_vmiddle">
						<div class="wishlist-wrap tf_inline_b tf_vmiddle">
			<a data-id="229" onclick="void(0)" class="wishlist-button tf_inline_b tf_textc" href="#" rel="nofollow">
				<svg  aria-label="Wishlist" class="tf_fa tf-ti-heart" role="img"><use href="#tf-ti-heart"></use></svg><span class="tooltip">Wishlist</span>			</a>
		</div> 
        									 <a onclick="return false;" class="quick-look themify-lightbox" href="https://127.0.0.1/e_commerce_project/wordpress/product/leggings/" rel="nofollow"><svg  aria-label="Quick Look" class="tf_fa tf-ti-zoom-in" role="img"><use href="#tf-ti-zoom-in"></use></svg><span class="tooltip">Quick Look</span></a>
													<div class="share-wrap">
	<a class="share-button" href="javascript:void(0);"><svg  aria-label="Share" class="tf_fa tf-ti-export" role="img"><use href="#tf-ti-export"></use></svg><span class="screen-reader-text">Share</span></a>
	<div class="social-share">
				    <a onclick="window.open('//twitter.com/intent/tweet?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fleggings&#038;text=Leggings','twitter','toolbar=0, status=0, width=650, height=360')" title="Twitter" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Twitter" class="tf_fa tf-ti-twitter-alt" role="img"><use href="#tf-ti-twitter-alt"></use></svg>		    </a>
				    <a onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fleggings&#038;t=Leggings&#038;original_referer=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fleggings%2F','facebook','toolbar=0, status=0, width=900, height=500')" title="Facebook" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Facebook" class="tf_fa tf-ti-facebook" role="img"><use href="#tf-ti-facebook"></use></svg>		    </a>
				    <a onclick="window.open('//pinterest.com/pin/create/button/?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fleggings&#038;description=Leggings&#038;media=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fwp-content%2Fuploads%2F2023%2F08%2FCategory-Jungle-Leggings-80.jpg','pinterest','toolbar=no,width=700,height=300')" title="Pinterest" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Pinterest" class="tf_fa tf-ti-pinterest" role="img"><use href="#tf-ti-pinterest"></use></svg>		    </a>
				    <a onclick="window.open('//www.linkedin.com/cws/share?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fleggings&#038;token=&#038;isFramed=true','linkedin','toolbar=no,width=550,height=550')" title="LinkedIn" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="LinkedIn" class="tf_fa tf-ti-linkedin" role="img"><use href="#tf-ti-linkedin"></use></svg>		    </a>
			</div>
</div>
<!-- .post-share -->
							</div>
							
				</div>
			</div>
		</div>
										</div>
												</li>
												<li class="post has-post-title has-post-date no-post-category no-post-tag has-post-comment has-post-author product type-product post-225 status-publish instock product_cat-essentials has-post-thumbnail sale featured shipping-taxable purchasable product-type-simple">
															
																										<figure class="post-image">
    	    
	<span class="onsale">Sale!</span>
	            	<a href="https://127.0.0.1/e_commerce_project/wordpress/product/bottles/" title="Bottles"><img data-tf-not-load="1" decoding="async" src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/Silver-Bottle.png" class="wp-post-image wp-image-189" title="Silver Bottle" alt="Silver Bottle"></a>
    </figure>																	
								<div class="post-content">
										    <div class="product-content">
		    <div class="product-content-inner-wrapper">
			    <div class="product-content-inner">
	    									
																																						<h3 class="product_title">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/bottles/" title="Bottles">
												
												Bottles
																								</a>
																					</h3>
																			  

									
	<span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>60.00</bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>55.00</bdi></span></ins></span>
<p class="add-to-cart-button"><a href="?add-to-cart=225" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="225" data-product_sku="" aria-label="Add &ldquo;Bottles&rdquo; to your basket" aria-describedby="" rel="nofollow">Add to basket</a></p>		<div class="product-share-wrap tf_inline_b tf_vmiddle">
						<div class="wishlist-wrap tf_inline_b tf_vmiddle">
			<a data-id="225" onclick="void(0)" class="wishlist-button tf_inline_b tf_textc" href="#" rel="nofollow">
				<svg  aria-label="Wishlist" class="tf_fa tf-ti-heart" role="img"><use href="#tf-ti-heart"></use></svg><span class="tooltip">Wishlist</span>			</a>
		</div> 
        									 <a onclick="return false;" class="quick-look themify-lightbox" href="https://127.0.0.1/e_commerce_project/wordpress/product/bottles/" rel="nofollow"><svg  aria-label="Quick Look" class="tf_fa tf-ti-zoom-in" role="img"><use href="#tf-ti-zoom-in"></use></svg><span class="tooltip">Quick Look</span></a>
													<div class="share-wrap">
	<a class="share-button" href="javascript:void(0);"><svg  aria-label="Share" class="tf_fa tf-ti-export" role="img"><use href="#tf-ti-export"></use></svg><span class="screen-reader-text">Share</span></a>
	<div class="social-share">
				    <a onclick="window.open('//twitter.com/intent/tweet?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fbottles&#038;text=Bottles','twitter','toolbar=0, status=0, width=650, height=360')" title="Twitter" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Twitter" class="tf_fa tf-ti-twitter-alt" role="img"><use href="#tf-ti-twitter-alt"></use></svg>		    </a>
				    <a onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fbottles&#038;t=Bottles&#038;original_referer=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fbottles%2F','facebook','toolbar=0, status=0, width=900, height=500')" title="Facebook" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Facebook" class="tf_fa tf-ti-facebook" role="img"><use href="#tf-ti-facebook"></use></svg>		    </a>
				    <a onclick="window.open('//pinterest.com/pin/create/button/?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fbottles&#038;description=Bottles&#038;media=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fwp-content%2Fuploads%2F2023%2F08%2FSilver-Bottle.png','pinterest','toolbar=no,width=700,height=300')" title="Pinterest" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Pinterest" class="tf_fa tf-ti-pinterest" role="img"><use href="#tf-ti-pinterest"></use></svg>		    </a>
				    <a onclick="window.open('//www.linkedin.com/cws/share?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fbottles&#038;token=&#038;isFramed=true','linkedin','toolbar=no,width=550,height=550')" title="LinkedIn" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="LinkedIn" class="tf_fa tf-ti-linkedin" role="img"><use href="#tf-ti-linkedin"></use></svg>		    </a>
			</div>
</div>
<!-- .post-share -->
							</div>
							
				</div>
			</div>
		</div>
										</div>
												</li>
												<li class="post has-post-title has-post-date no-post-category no-post-tag has-post-comment has-post-author product type-product post-177 status-publish instock product_cat-rings has-post-thumbnail sale featured shipping-taxable purchasable product-type-simple">
															
																										<figure class="post-image">
    	    
	<span class="onsale">Sale!</span>
	            	<a href="https://127.0.0.1/e_commerce_project/wordpress/product/rings/" title="Rings"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" decoding="async" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/r4.jpg" class="tf_svg_lazy wp-post-image wp-image-163" title="r4" alt="r4"><noscript><img data-tf-not-load src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/r4.jpg" class="wp-post-image wp-image-163" title="r4" alt="r4"></noscript></a>
    </figure>																	
								<div class="post-content">
										    <div class="product-content">
		    <div class="product-content-inner-wrapper">
			    <div class="product-content-inner">
	    									
																																						<h3 class="product_title">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/rings/" title="Rings">
												
												Rings
																								</a>
																					</h3>
																			  

									
	<span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>90.00</bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>79.00</bdi></span></ins></span>
<p class="add-to-cart-button"><a href="?add-to-cart=177" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="177" data-product_sku="" aria-label="Add &ldquo;Rings&rdquo; to your basket" aria-describedby="" rel="nofollow">Add to basket</a></p>		<div class="product-share-wrap tf_inline_b tf_vmiddle">
						<div class="wishlist-wrap tf_inline_b tf_vmiddle">
			<a data-id="177" onclick="void(0)" class="wishlist-button tf_inline_b tf_textc" href="#" rel="nofollow">
				<svg  aria-label="Wishlist" class="tf_fa tf-ti-heart" role="img"><use href="#tf-ti-heart"></use></svg><span class="tooltip">Wishlist</span>			</a>
		</div> 
        									 <a onclick="return false;" class="quick-look themify-lightbox" href="https://127.0.0.1/e_commerce_project/wordpress/product/rings/" rel="nofollow"><svg  aria-label="Quick Look" class="tf_fa tf-ti-zoom-in" role="img"><use href="#tf-ti-zoom-in"></use></svg><span class="tooltip">Quick Look</span></a>
													<div class="share-wrap">
	<a class="share-button" href="javascript:void(0);"><svg  aria-label="Share" class="tf_fa tf-ti-export" role="img"><use href="#tf-ti-export"></use></svg><span class="screen-reader-text">Share</span></a>
	<div class="social-share">
				    <a onclick="window.open('//twitter.com/intent/tweet?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Frings&#038;text=Rings','twitter','toolbar=0, status=0, width=650, height=360')" title="Twitter" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Twitter" class="tf_fa tf-ti-twitter-alt" role="img"><use href="#tf-ti-twitter-alt"></use></svg>		    </a>
				    <a onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Frings&#038;t=Rings&#038;original_referer=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Frings%2F','facebook','toolbar=0, status=0, width=900, height=500')" title="Facebook" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Facebook" class="tf_fa tf-ti-facebook" role="img"><use href="#tf-ti-facebook"></use></svg>		    </a>
				    <a onclick="window.open('//pinterest.com/pin/create/button/?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Frings&#038;description=Rings&#038;media=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fwp-content%2Fuploads%2F2023%2F08%2Fr4.jpg','pinterest','toolbar=no,width=700,height=300')" title="Pinterest" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Pinterest" class="tf_fa tf-ti-pinterest" role="img"><use href="#tf-ti-pinterest"></use></svg>		    </a>
				    <a onclick="window.open('//www.linkedin.com/cws/share?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Frings&#038;token=&#038;isFramed=true','linkedin','toolbar=no,width=550,height=550')" title="LinkedIn" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="LinkedIn" class="tf_fa tf-ti-linkedin" role="img"><use href="#tf-ti-linkedin"></use></svg>		    </a>
			</div>
</div>
<!-- .post-share -->
							</div>
							
				</div>
			</div>
		</div>
										</div>
												</li>
												<li class="post has-post-title has-post-date no-post-category no-post-tag has-post-comment has-post-author product type-product post-165 status-publish instock product_cat-essentials has-post-thumbnail sale featured shipping-taxable purchasable product-type-simple">
															
																										<figure class="post-image">
    	    
	<span class="onsale">Sale!</span>
	            	<a href="https://127.0.0.1/e_commerce_project/wordpress/product/simple-products-3/" title="Simple products"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" decoding="async" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/h4.jpg" class="tf_svg_lazy wp-post-image wp-image-159" title="h4" alt="h4"><noscript><img data-tf-not-load src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/h4.jpg" class="wp-post-image wp-image-159" title="h4" alt="h4"></noscript></a>
    </figure>																	
								<div class="post-content">
										    <div class="product-content">
		    <div class="product-content-inner-wrapper">
			    <div class="product-content-inner">
	    									
																																						<h3 class="product_title">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/simple-products-3/" title="Simple products">
												
												Simple products
																								</a>
																					</h3>
																			  

									
	<span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>599.00</bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>450.00</bdi></span></ins></span>
<p class="add-to-cart-button"><a href="?add-to-cart=165" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="165" data-product_sku="" aria-label="Add &ldquo;Simple products&rdquo; to your basket" aria-describedby="" rel="nofollow">Add to basket</a></p>		<div class="product-share-wrap tf_inline_b tf_vmiddle">
						<div class="wishlist-wrap tf_inline_b tf_vmiddle">
			<a data-id="165" onclick="void(0)" class="wishlist-button tf_inline_b tf_textc" href="#" rel="nofollow">
				<svg  aria-label="Wishlist" class="tf_fa tf-ti-heart" role="img"><use href="#tf-ti-heart"></use></svg><span class="tooltip">Wishlist</span>			</a>
		</div> 
        									 <a onclick="return false;" class="quick-look themify-lightbox" href="https://127.0.0.1/e_commerce_project/wordpress/product/simple-products-3/" rel="nofollow"><svg  aria-label="Quick Look" class="tf_fa tf-ti-zoom-in" role="img"><use href="#tf-ti-zoom-in"></use></svg><span class="tooltip">Quick Look</span></a>
													<div class="share-wrap">
	<a class="share-button" href="javascript:void(0);"><svg  aria-label="Share" class="tf_fa tf-ti-export" role="img"><use href="#tf-ti-export"></use></svg><span class="screen-reader-text">Share</span></a>
	<div class="social-share">
				    <a onclick="window.open('//twitter.com/intent/tweet?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fsimple-products-3&#038;text=Simple+products','twitter','toolbar=0, status=0, width=650, height=360')" title="Twitter" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Twitter" class="tf_fa tf-ti-twitter-alt" role="img"><use href="#tf-ti-twitter-alt"></use></svg>		    </a>
				    <a onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fsimple-products-3&#038;t=Simple+products&#038;original_referer=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fsimple-products-3%2F','facebook','toolbar=0, status=0, width=900, height=500')" title="Facebook" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Facebook" class="tf_fa tf-ti-facebook" role="img"><use href="#tf-ti-facebook"></use></svg>		    </a>
				    <a onclick="window.open('//pinterest.com/pin/create/button/?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fsimple-products-3&#038;description=Simple+products&#038;media=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fwp-content%2Fuploads%2F2023%2F08%2Fh4.jpg','pinterest','toolbar=no,width=700,height=300')" title="Pinterest" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Pinterest" class="tf_fa tf-ti-pinterest" role="img"><use href="#tf-ti-pinterest"></use></svg>		    </a>
				    <a onclick="window.open('//www.linkedin.com/cws/share?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fsimple-products-3&#038;token=&#038;isFramed=true','linkedin','toolbar=no,width=550,height=550')" title="LinkedIn" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="LinkedIn" class="tf_fa tf-ti-linkedin" role="img"><use href="#tf-ti-linkedin"></use></svg>		    </a>
			</div>
</div>
<!-- .post-share -->
							</div>
							
				</div>
			</div>
		</div>
										</div>
												</li>
												<li class="post has-post-title has-post-date no-post-category no-post-tag has-post-comment has-post-author product type-product post-102 status-publish instock product_cat-leather-goods product_cat-watches has-post-thumbnail sale featured shipping-taxable purchasable product-type-variable has-default-attributes">
															
																										<figure class="post-image">
    	    
	<span class="onsale">Sale!</span>
	            	<a href="https://127.0.0.1/e_commerce_project/wordpress/product/variable-products/" title="Variable products"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" decoding="async" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/5-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band.png" class="tf_svg_lazy wp-post-image wp-image-95" title="5-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band" alt="5-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band"><noscript><img data-tf-not-load src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/5-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band.png" class="wp-post-image wp-image-95" title="5-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band" alt="5-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band"></noscript></a>
    </figure>																	
								<div class="post-content">
										    <div class="product-content">
		    <div class="product-content-inner-wrapper">
			    <div class="product-content-inner">
	    									
																																						<h3 class="product_title">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/variable-products/" title="Variable products">
												
												Variable products
																								</a>
																					</h3>
																			  

									
	<span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>99.00</bdi></span> &ndash; <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>115.00</bdi></span></span>
<p class="add-to-cart-button"><a href="https://127.0.0.1/e_commerce_project/wordpress/product/variable-products/" data-quantity="1" class="button product_type_variable add_to_cart_button variable-link themify-lightbox" data-product_id="102" data-product_sku="" aria-label="Select options for &ldquo;Variable products&rdquo;" aria-describedby="This product has multiple variants. The options may be chosen on the product page" rel="nofollow">Select options</a></p>		<div class="product-share-wrap tf_inline_b tf_vmiddle">
						<div class="wishlist-wrap tf_inline_b tf_vmiddle">
			<a data-id="102" onclick="void(0)" class="wishlist-button tf_inline_b tf_textc" href="#" rel="nofollow">
				<svg  aria-label="Wishlist" class="tf_fa tf-ti-heart" role="img"><use href="#tf-ti-heart"></use></svg><span class="tooltip">Wishlist</span>			</a>
		</div> 
        									 <a onclick="return false;" class="quick-look themify-lightbox" href="https://127.0.0.1/e_commerce_project/wordpress/product/variable-products/" rel="nofollow"><svg  aria-label="Quick Look" class="tf_fa tf-ti-zoom-in" role="img"><use href="#tf-ti-zoom-in"></use></svg><span class="tooltip">Quick Look</span></a>
													<div class="share-wrap">
	<a class="share-button" href="javascript:void(0);"><svg  aria-label="Share" class="tf_fa tf-ti-export" role="img"><use href="#tf-ti-export"></use></svg><span class="screen-reader-text">Share</span></a>
	<div class="social-share">
				    <a onclick="window.open('//twitter.com/intent/tweet?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fvariable-products&#038;text=Variable+products','twitter','toolbar=0, status=0, width=650, height=360')" title="Twitter" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Twitter" class="tf_fa tf-ti-twitter-alt" role="img"><use href="#tf-ti-twitter-alt"></use></svg>		    </a>
				    <a onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fvariable-products&#038;t=Variable+products&#038;original_referer=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fvariable-products%2F','facebook','toolbar=0, status=0, width=900, height=500')" title="Facebook" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Facebook" class="tf_fa tf-ti-facebook" role="img"><use href="#tf-ti-facebook"></use></svg>		    </a>
				    <a onclick="window.open('//pinterest.com/pin/create/button/?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fvariable-products&#038;description=Variable+products&#038;media=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fwp-content%2Fuploads%2F2023%2F08%2F5-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band.png','pinterest','toolbar=no,width=700,height=300')" title="Pinterest" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Pinterest" class="tf_fa tf-ti-pinterest" role="img"><use href="#tf-ti-pinterest"></use></svg>		    </a>
				    <a onclick="window.open('//www.linkedin.com/cws/share?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fvariable-products&#038;token=&#038;isFramed=true','linkedin','toolbar=no,width=550,height=550')" title="LinkedIn" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="LinkedIn" class="tf_fa tf-ti-linkedin" role="img"><use href="#tf-ti-linkedin"></use></svg>		    </a>
			</div>
</div>
<!-- .post-share -->
							</div>
							
				</div>
			</div>
		</div>
										</div>
												</li>
												<li class="post has-post-title has-post-date no-post-category no-post-tag has-post-comment has-post-author product type-product post-86 status-publish instock product_cat-backpacks product_cat-leather-goods has-post-thumbnail sale featured shipping-taxable purchasable product-type-simple">
															
																										<figure class="post-image">
    	    
	<span class="onsale">Sale!</span>
	            	<a href="https://127.0.0.1/e_commerce_project/wordpress/product/backpack/" title="Simple products"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" decoding="async" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/1.jpg" class="tf_svg_lazy wp-post-image wp-image-87" title="1" alt="1"><noscript><img data-tf-not-load src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/1.jpg" class="wp-post-image wp-image-87" title="1" alt="1"></noscript></a>
    </figure>																	
								<div class="post-content">
										    <div class="product-content">
		    <div class="product-content-inner-wrapper">
			    <div class="product-content-inner">
	    									
																																						<h3 class="product_title">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/backpack/" title="Simple products">
												
												Simple products
																								</a>
																					</h3>
																			  

									
	<span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>199.00</bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>149.00</bdi></span></ins></span>
<p class="add-to-cart-button"><a href="https://127.0.0.1/e_commerce_project/wordpress/product/backpack/" data-quantity="1" class="button product_type_simple add_to_cart_button" data-product_id="86" data-product_sku="" aria-label="Add &ldquo;Simple products&rdquo; to your basket" aria-describedby="" rel="nofollow">Select options</a></p>		<div class="product-share-wrap tf_inline_b tf_vmiddle">
						<div class="wishlist-wrap tf_inline_b tf_vmiddle">
			<a data-id="86" onclick="void(0)" class="wishlist-button tf_inline_b tf_textc" href="#" rel="nofollow">
				<svg  aria-label="Wishlist" class="tf_fa tf-ti-heart" role="img"><use href="#tf-ti-heart"></use></svg><span class="tooltip">Wishlist</span>			</a>
		</div> 
        									 <a onclick="return false;" class="quick-look themify-lightbox" href="https://127.0.0.1/e_commerce_project/wordpress/product/backpack/" rel="nofollow"><svg  aria-label="Quick Look" class="tf_fa tf-ti-zoom-in" role="img"><use href="#tf-ti-zoom-in"></use></svg><span class="tooltip">Quick Look</span></a>
													<div class="share-wrap">
	<a class="share-button" href="javascript:void(0);"><svg  aria-label="Share" class="tf_fa tf-ti-export" role="img"><use href="#tf-ti-export"></use></svg><span class="screen-reader-text">Share</span></a>
	<div class="social-share">
				    <a onclick="window.open('//twitter.com/intent/tweet?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fbackpack&#038;text=Simple+products','twitter','toolbar=0, status=0, width=650, height=360')" title="Twitter" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Twitter" class="tf_fa tf-ti-twitter-alt" role="img"><use href="#tf-ti-twitter-alt"></use></svg>		    </a>
				    <a onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fbackpack&#038;t=Simple+products&#038;original_referer=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fbackpack%2F','facebook','toolbar=0, status=0, width=900, height=500')" title="Facebook" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Facebook" class="tf_fa tf-ti-facebook" role="img"><use href="#tf-ti-facebook"></use></svg>		    </a>
				    <a onclick="window.open('//pinterest.com/pin/create/button/?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fbackpack&#038;description=Simple+products&#038;media=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fwp-content%2Fuploads%2F2023%2F08%2F1.jpg','pinterest','toolbar=no,width=700,height=300')" title="Pinterest" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="Pinterest" class="tf_fa tf-ti-pinterest" role="img"><use href="#tf-ti-pinterest"></use></svg>		    </a>
				    <a onclick="window.open('//www.linkedin.com/cws/share?url=https%3A%2F%2F127.0.0.1%2Fe_commerce_project%2Fwordpress%2Fproduct%2Fbackpack&#038;token=&#038;isFramed=true','linkedin','toolbar=no,width=550,height=550')" title="LinkedIn" rel="nofollow" href="javascript:void(0);" class="share">
			<svg  aria-label="LinkedIn" class="tf_fa tf-ti-linkedin" role="img"><use href="#tf-ti-linkedin"></use></svg>		    </a>
			</div>
</div>
<!-- .post-share -->
							</div>
							
				</div>
			</div>
		</div>
										</div>
												</li>
													</ul>
				</div>
	<!-- module text -->
<div  class="module module-text tb_q0vc334   " data-lazy="1">
        <div  class="tb_text_wrap">
    <p style="text-align: center;">Categories</p>    </div>
</div>
<!-- /module text -->                    </div><!-- .tb-column-inner -->
                            </div><!-- .module_column -->
            	    </div><!-- .row_inner -->
	</div><!-- .module_row -->
				<!-- module_row -->
	<div  data-lazy="1" class="module_row themify_builder_row tb_uvip601 tf_w tf_clearfix">
	    			<div class="row_inner col_align_top tb_col_count_1 tf_box tf_rel">
		            <div  data-lazy="1" class="module_column tb-column col-full tb_0kb9601 first">
                                                        <div class="tb-column-inner tf_box tf_w">
                        <!-- module product categories -->
<div  id="tb_sf9m616" class="module woocommerce module-product-categories tb_sf9m616  shows_products" data-lazy="1">
				<ul class="loops-wrapper products grid5 tf_clear">
									<li class="product-category product">

						<a aria-label="Visit product category watches" href="https://127.0.0.1/e_commerce_project/wordpress/product-category/watches/"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" class="tf_svg_lazy" decoding="async" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/4-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band.png" alt="watches" width="300" height="300" /><noscript><img data-tf-not-load src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/4-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band.png" alt="watches" width="300" height="300" /></noscript></a>								<div class="product-thumbs">
																													<div class="post">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/variable-products/">
																							<br />
<b>Warning</b>:  Undefined variable $im in <b>C:\xampp\htdocs\e_commerce_project\wordpress\wp-content\themes\themify-shoppe\themify\img.php</b> on line <b>296</b><br />
<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" width="640" height="640" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/5-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band.png" class="tf_svg_lazy attachment-shop_catalog size-shop_catalog" alt="" decoding="async" /><noscript><img width="640" height="640" data-tf-not-load data-no-script src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/5-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band.png" class="attachment-shop_catalog size-shop_catalog" alt="" decoding="async" /></noscript>																							</a>
																					</div>
																	</div>
														<a aria-label="Visit product category watches" href="https://127.0.0.1/e_commerce_project/wordpress/product-category/watches/">						<h3>
							watches <mark class="count">(1)</mark>						</h3>
						</a>
						                        					</li>
										<li class="product-category product">

						<a aria-label="Visit product category Rings" href="https://127.0.0.1/e_commerce_project/wordpress/product-category/rings/"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" class="tf_svg_lazy" decoding="async" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/r4-1.jpg" alt="Rings" width="300" height="300" /><noscript><img data-tf-not-load src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/r4-1.jpg" alt="Rings" width="300" height="300" /></noscript></a>								<div class="product-thumbs">
																													<div class="post">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/rings/">
																							<br />
<b>Warning</b>:  Undefined variable $im in <b>C:\xampp\htdocs\e_commerce_project\wordpress\wp-content\themes\themify-shoppe\themify\img.php</b> on line <b>296</b><br />
<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" width="474" height="385" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/r4.jpg" class="tf_svg_lazy attachment-shop_catalog size-shop_catalog" alt="" decoding="async" /><noscript><img width="474" height="385" data-tf-not-load data-no-script src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/r4.jpg" class="attachment-shop_catalog size-shop_catalog" alt="" decoding="async" /></noscript>																							</a>
																					</div>
																	</div>
														<a aria-label="Visit product category Rings" href="https://127.0.0.1/e_commerce_project/wordpress/product-category/rings/">						<h3>
							Rings <mark class="count">(3)</mark>						</h3>
						</a>
						                        					</li>
										<li class="product-category product">

						<a aria-label="Visit product category Leather goods" href="https://127.0.0.1/e_commerce_project/wordpress/product-category/leather-goods/"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" class="tf_svg_lazy" decoding="async" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/4.jpg" alt="Leather goods" width="300" height="300" /><noscript><img data-tf-not-load src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/4.jpg" alt="Leather goods" width="300" height="300" /></noscript></a>								<div class="product-thumbs">
																													<div class="post">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/suitcase/">
																							<br />
<b>Warning</b>:  Undefined variable $im in <b>C:\xampp\htdocs\e_commerce_project\wordpress\wp-content\themes\themify-shoppe\themify\img.php</b> on line <b>296</b><br />
<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" width="1920" height="1280" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/Hero-2-2.jpeg" class="tf_svg_lazy attachment-shop_catalog size-shop_catalog" alt="" decoding="async" /><noscript><img width="1920" height="1280" data-tf-not-load data-no-script src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/Hero-2-2.jpeg" class="attachment-shop_catalog size-shop_catalog" alt="" decoding="async" /></noscript>																							</a>
																					</div>
																	</div>
														<a aria-label="Visit product category Leather goods" href="https://127.0.0.1/e_commerce_project/wordpress/product-category/leather-goods/">						<h3>
							Leather goods <mark class="count">(3)</mark>						</h3>
						</a>
						                        					</li>
										<li class="product-category product">

						<a aria-label="Visit product category Essentials" href="https://127.0.0.1/e_commerce_project/wordpress/product-category/essentials/"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" class="tf_svg_lazy" decoding="async" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/Silver-Bottle.png" alt="Essentials" width="300" height="300" /><noscript><img data-tf-not-load src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/Silver-Bottle.png" alt="Essentials" width="300" height="300" /></noscript></a>								<div class="product-thumbs">
																													<div class="post">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/leggings-2/">
																							<br />
<b>Warning</b>:  Undefined variable $im in <b>C:\xampp\htdocs\e_commerce_project\wordpress\wp-content\themes\themify-shoppe\themify\img.php</b> on line <b>296</b><br />
<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" width="1000" height="1000" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/Category-Sports-Leggings-80-2.jpg" class="tf_svg_lazy attachment-shop_catalog size-shop_catalog" alt="" decoding="async" /><noscript><img width="1000" height="1000" data-tf-not-load data-no-script src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/Category-Sports-Leggings-80-2.jpg" class="attachment-shop_catalog size-shop_catalog" alt="" decoding="async" /></noscript>																							</a>
																					</div>
																	</div>
														<a aria-label="Visit product category Essentials" href="https://127.0.0.1/e_commerce_project/wordpress/product-category/essentials/">						<h3>
							Essentials <mark class="count">(5)</mark>						</h3>
						</a>
						                        					</li>
										<li class="product-category product">

						<a aria-label="Visit product category Backpacks" href="https://127.0.0.1/e_commerce_project/wordpress/product-category/leather-goods/backpacks/"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" class="tf_svg_lazy" decoding="async" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/1.jpg" alt="Backpacks" width="300" height="300" /><noscript><img data-tf-not-load src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/1.jpg" alt="Backpacks" width="300" height="300" /></noscript></a>								<div class="product-thumbs">
																													<div class="post">
																							<a href="https://127.0.0.1/e_commerce_project/wordpress/product/backpack/">
																							<br />
<b>Warning</b>:  Undefined variable $im in <b>C:\xampp\htdocs\e_commerce_project\wordpress\wp-content\themes\themify-shoppe\themify\img.php</b> on line <b>296</b><br />
<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-lazy="1" width="474" height="474" data-tf-src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/1.jpg" class="tf_svg_lazy attachment-shop_catalog size-shop_catalog" alt="" decoding="async" /><noscript><img width="474" height="474" data-tf-not-load data-no-script src="https://127.0.0.1/e_commerce_project/wordpress/wp-content/uploads/2023/08/1.jpg" class="attachment-shop_catalog size-shop_catalog" alt="" decoding="async" /></noscript>																							</a>
																					</div>
																	</div>
														<a aria-label="Visit product category Backpacks" href="https://127.0.0.1/e_commerce_project/wordpress/product-category/leather-goods/backpacks/">						<h3>
							Backpacks <mark class="count">(1)</mark>						</h3>
						</a>
						                        					</li>
								</ul>
            					</div>
<!-- module product categories -->
                    </div><!-- .tb-column-inner -->
                            </div><!-- .module_column -->
            	    </div><!-- .row_inner -->
	</div><!-- .module_row -->
				<!-- module_row -->
	<div  data-lazy="1" class="module_row themify_builder_row tb_ka3c750 tf_w tf_clearfix">
	    			<div class="row_inner col_align_top tb_col_count_1 tf_box tf_rel">
		            <div  data-lazy="1" class="module_column tb-column col-full tb_6krg750 first">
                                                        <div class="tb-column-inner tf_box tf_w">
                        <!-- module text -->
<div  class="module module-text tb_q5z1305   " data-lazy="1">
        <div  class="tb_text_wrap">
    <h4 style="text-align: center;">View range</h4>
<h2 style="text-align: center;">Shop Collections</h2>    </div>
</div>
<!-- /module text -->	<div  data-lazy="1" class="module_subrow themify_builder_sub_row tb_poi8126 tf_w tf_clearfix">
	    			<div class="subrow_inner col_align_top tb_col_count_2 tf_box tf_w">
		            <div  data-lazy="1" class="module_column sub_column col4-2 tb_sf57126 first">
                    <div class="builder_row_cover tf_abs"></div>                                    <div class="tb-column-inner tf_box tf_w">
                        <!-- module text -->
<div  class="module module-text tb_ih0k188  repeat " data-lazy="1">
        <div  class="tb_text_wrap">
    <h2 style="text-align: center;">Desks</h2>    </div>
</div>
<!-- /module text --><!-- module buttons -->
<div  class="module module-buttons tb_5qzl904 buttons-horizontal solid " data-lazy="1">
    	<div class="module-buttons-item tf_inline_b">
							<a href="http://127.0.0.1/e_commerce_project/wordpress/shop/" class="ui builder_button tb_default_color" >
											<span class="tf_inline_b tf_vmiddle">Shop now</span>
											</a>
			    	</div>
    </div>
<!-- /module buttons -->
                    </div><!-- .tb-column-inner -->
                            </div><!-- .module_column -->
                        <div  data-lazy="1" class="module_column sub_column col4-2 tb_a9n4126 last">
                    <div class="builder_row_cover tf_abs"></div>                                    <div class="tb-column-inner tf_box tf_w">
                        <!-- module text -->
<div  class="module module-text tb_1t1r828   " data-lazy="1">
        <div  class="tb_text_wrap">
    <h2 style="text-align: center;">Living</h2>    </div>
</div>
<!-- /module text --><!-- module buttons -->
<div  class="module module-buttons tb_90pv673 buttons-horizontal solid " data-lazy="1">
    	<div class="module-buttons-item tf_inline_b">
							<a href="http://127.0.0.1/e_commerce_project/wordpress/shop/" class="ui builder_button tb_default_color" >
											<span class="tf_inline_b tf_vmiddle">Shop now</span>
											</a>
			    	</div>
    </div>
<!-- /module buttons -->
                    </div><!-- .tb-column-inner -->
                            </div><!-- .module_column -->
            	    </div><!-- .subrow_inner -->
	</div><!-- .themify_builder_sub_row -->
		<div  data-lazy="1" class="module_subrow themify_builder_sub_row tb_3wr4913 tf_w tf_clearfix">
	    			<div class="subrow_inner col_align_top tb_col_count_2 tf_box tf_w">
		            <div  data-lazy="1" class="module_column sub_column col4-2 tb_xtdd914 first">
                    <div class="builder_row_cover tf_abs"></div>                                    <div class="tb-column-inner tf_box tf_w">
                        <!-- module text -->
<div  class="module module-text tb_xe2k914  repeat " data-lazy="1">
        <div  class="tb_text_wrap">
    <h2 style="text-align: center;">Essentials</h2>    </div>
</div>
<!-- /module text --><!-- module buttons -->
<div  class="module module-buttons tb_rwcl914 buttons-horizontal solid " data-lazy="1">
    	<div class="module-buttons-item tf_inline_b">
							<a href="http://127.0.0.1/e_commerce_project/wordpress/shop/" class="ui builder_button tb_default_color" >
											<span class="tf_inline_b tf_vmiddle">Shop now</span>
											</a>
			    	</div>
    </div>
<!-- /module buttons -->
                    </div><!-- .tb-column-inner -->
                            </div><!-- .module_column -->
                        <div  data-lazy="1" class="module_column sub_column col4-2 tb_klju914 last">
                    <div class="builder_row_cover tf_abs"></div>                                    <div class="tb-column-inner tf_box tf_w">
                        <!-- module text -->
<div  class="module module-text tb_z1xh914   " data-lazy="1">
        <div  class="tb_text_wrap">
    <h2 style="text-align: center;">Women&#8217;s</h2>    </div>
</div>
<!-- /module text --><!-- module buttons -->
<div  class="module module-buttons tb_5296914 buttons-horizontal solid " data-lazy="1">
    	<div class="module-buttons-item tf_inline_b">
							<a href="http://127.0.0.1/e_commerce_project/wordpress/shop/" class="ui builder_button tb_default_color" >
											<span class="tf_inline_b tf_vmiddle">Shop now</span>
											</a>
			    	</div>
    </div>
<!-- /module buttons -->
                    </div><!-- .tb-column-inner -->
                            </div><!-- .module_column -->
            	    </div><!-- .subrow_inner -->
	</div><!-- .themify_builder_sub_row -->
	                    </div><!-- .tb-column-inner -->
                            </div><!-- .module_column -->
            	    </div><!-- .row_inner -->
	</div><!-- .module_row -->
	</div>
<!--/themify_builder_content-->	    <!-- /comments -->
	</div>
	<!-- /.post-content -->
					</div>
				<!-- /.type-page -->
				    </main>
    <!-- /content -->
    </div>
<!-- /layout-container -->
    </div>
<!-- /body -->
        <div id="footerwrap" class="tf_clear tf_box">

	    
	    		<div class="footer-social-wrap tf_w tf_overflow">
																		<div class="footer-social-badge tf_textc tf_vmiddle tf_overflow">
					<a class="tfb-twitter-alt" data-lazy="1" href="">
					    <svg  class="tf_fa tf-ti-twitter" aria-hidden="true"><use href="#tf-ti-twitter"></use></svg>						<strong>Twitter</strong>
						<span></span>
					</a>
				</div>
																											<div class="footer-social-badge tf_textc tf_vmiddle tf_overflow">
					<a class="tfb-pinterest-alt" data-lazy="1" href="">
					    <svg  class="tf_fa tf-ti-pinterest" aria-hidden="true"><use href="#tf-ti-pinterest"></use></svg>						<strong>Pinterest</strong>
						<span></span>
					</a>
				</div>
																											<div class="footer-social-badge tf_textc tf_vmiddle tf_overflow">
					<a class="tfb-linkedin-alt" data-lazy="1" href="">
					    <svg  class="tf_fa tf-ti-linkedin" aria-hidden="true"><use href="#tf-ti-linkedin"></use></svg>						<strong>Linkedin</strong>
						<span></span>
					</a>
				</div>
																											<div class="footer-social-badge tf_textc tf_vmiddle tf_overflow">
					<a class="tfb-instagram-alt" data-lazy="1" href="">
					    <svg  class="tf_fa tf-ti-instagram" aria-hidden="true"><use href="#tf-ti-instagram"></use></svg>						<strong>Instagram</strong>
						<span></span>
					</a>
				</div>
								</div>


	    <footer id="footer" class="pagewidth tf_box tf_clearfix" itemscope="itemscope" itemtype="https://schema.org/WPFooter">

		    
		    <div class="footer-column-wrap tf_clear tf_clearfix">
			    <div class="footer-logo-wrap tf_left">
				    					    <div id="footer-logo"><a href="https://127.0.0.1/e_commerce_project/wordpress" title="ShopEase"><span>ShopEase</span></a></div>																	  
					    <!-- /footer-logo -->
				    				    			    </div>


			    <!-- /footer-logo-wrap -->
			    
				    <div class="footer-widgets-wrap tf_left"> 
					        
	<div class="footer-widgets tf_clear tf_clearfix">
								<div class="col3-1 first">
				<div id="nav_menu-7" class="widget widget_nav_menu"><div class="menu-footer-1-container"><ul id="menu-footer-1" class="menu"><li id="menu-item-321" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-321"><a href="https://127.0.0.1/e_commerce_project/wordpress/home/about/">About</a></li>
<li id="menu-item-323" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-323"><a href="https://127.0.0.1/e_commerce_project/wordpress/contact/">Contact</a></li>
<li id="menu-item-324" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-324"><a href="https://127.0.0.1/e_commerce_project/wordpress/shop-2/">Shop</a></li>
<li id="menu-item-325" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-325"><a href="https://127.0.0.1/e_commerce_project/wordpress/wishlist/">Wishlist</a></li>
</ul></div></div>			</div>
								<div class="col3-1">
				<div id="nav_menu-6" class="widget widget_nav_menu"><div class="menu-footer-2-container"><ul id="menu-footer-2" class="menu"><li id="menu-item-326" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-25 current_page_item menu-item-326"><a href="https://127.0.0.1/e_commerce_project/wordpress/" aria-current="page">Home</a></li>
<li id="menu-item-327" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-327"><a href="https://127.0.0.1/e_commerce_project/wordpress/home/about/">About</a></li>
<li id="menu-item-328" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-328"><a rel="privacy-policy" href="https://127.0.0.1/e_commerce_project/wordpress/privacy-policy/">Privacy Policy</a></li>
<li id="menu-item-329" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-329"><a href="https://127.0.0.1/e_commerce_project/wordpress/delivery-returns/">Delivery &#038; Returns</a></li>
<li id="menu-item-330" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-330"><a href="https://127.0.0.1/e_commerce_project/wordpress/shop-2/">Shop</a></li>
<li id="menu-item-331" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-331"><a href="https://127.0.0.1/e_commerce_project/wordpress/wishlist/">Wishlist</a></li>
</ul></div></div>			</div>
								<div class="col3-1">
				<div id="nav_menu-4" class="widget widget_nav_menu"><h4 class="widgettitle">Contact us</h4><div class="menu-footer-3-container"><ul id="menu-footer-3" class="menu"><li id="menu-item-332" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-25 current_page_item menu-item-332"><a href="https://127.0.0.1/e_commerce_project/wordpress/" aria-current="page">Home</a></li>
<li id="menu-item-333" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-333"><a href="https://127.0.0.1/e_commerce_project/wordpress/home/about/">About</a></li>
<li id="menu-item-334" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-334"><a href="https://127.0.0.1/e_commerce_project/wordpress/shop-2/">Shop</a></li>
</ul></div></div><div id="themify-social-links-2" class="widget themify-social-links"><ul class="social-links horizontal">
                        <li class="social-link-item twitter font-icon icon-medium">
                            <a href="http://www.twitter.com" aria-label="twitter" target="_blank" rel="noopener"><em><svg  aria-label="Twitter" class="tf_fa tf-fab-twitter" role="img"><use href="#tf-fab-twitter"></use></svg></em>  </a>
                        </li>
                        <!-- /themify-link-item -->
                        <li class="social-link-item facebook font-icon icon-medium">
                            <a href="http://www.facebook.com" aria-label="facebook" target="_blank" rel="noopener"><em><svg  aria-label="Facebook" class="tf_fa tf-fab-facebook" role="img"><use href="#tf-fab-facebook"></use></svg></em>  </a>
                        </li>
                        <!-- /themify-link-item -->
                        <li class="social-link-item youtube font-icon icon-medium">
                            <a href="http://www.youtube.com" aria-label="youtube" target="_blank" rel="noopener"><em><svg  aria-label="YouTube" class="tf_fa tf-fab-youtube" role="img"><use href="#tf-fab-youtube"></use></svg></em>  </a>
                        </li>
                        <!-- /themify-link-item --></ul></div>			</div>
		
	</div>
	<!-- /.footer-widgets -->

				    </div>
				    <!-- /footer-widgets-wrap -->
			    
			    				    				    <div class="footer-nav-wrap tf_clear tf_textc">
					    				    </div>
				    <!-- /.footer-nav-wrap -->
			    
				    <div class="footer-text-outer tf_w">

					    <div class="back-top tf_vmiddle tf_inline_b tf_textc tf_clearfix "><div class="arrow-up"><a aria-label="Back to top" rel="nofollow" href="#header"><span class="screen-reader-text">Back to top</span></a></div></div>
						<div class="footer-text tf_vmiddle tf_inline_b tf_clearfix">
															<div class="one">&copy; <a href="https://127.0.0.1/e_commerce_project/wordpress">ShopEase</a> 2023</div>													</div>
						<!-- /.footer-text -->

				    </div>

		    </div>

		    	    </footer>
	    	    <!-- /#footer -->

	    
    </div>
    <!-- /#footerwrap -->
    </div>
<!-- /#pagewrap -->

		
<!-- wp_footer -->
                <!--googleoff:all-->
                <!--noindex-->
                <!--noptimize-->
                <script id="tf_vars" data-no-optimize="1" data-noptimize="1" defer="defer" src="data:text/javascript;base64,dmFyIHRoZW1pZnlTY3JpcHQgPSB7ImhlYWRlclR5cGUiOiJoZWFkZXItbG9nby1sZWZ0IiwiaW5maW5pdGVVUkwiOiIxIiwiYXV0b0luZmluaXRlIjoiYXV0byIsIndjX2dhbCI6eyJmbGV4c2xpZGVyIjp7InMiOiJodHRwczpcL1wvMTI3LjAuMC4xXC9lX2NvbW1lcmNlX3Byb2plY3RcL3dvcmRwcmVzc1wvd3AtY29udGVudFwvcGx1Z2luc1wvd29vY29tbWVyY2VcL2Fzc2V0c1wvanNcL2ZsZXhzbGlkZXJcL2pxdWVyeS5mbGV4c2xpZGVyLm1pbi5qcyIsInYiOiIyLjcuMi13Yy44LjAuMSJ9LCJwaG90b3N3aXBlLXVpLWRlZmF1bHQiOnsicyI6Imh0dHBzOlwvXC8xMjcuMC4wLjFcL2VfY29tbWVyY2VfcHJvamVjdFwvd29yZHByZXNzXC93cC1jb250ZW50XC9wbHVnaW5zXC93b29jb21tZXJjZVwvYXNzZXRzXC9qc1wvcGhvdG9zd2lwZVwvcGhvdG9zd2lwZS11aS1kZWZhdWx0Lm1pbi5qcyIsInYiOiI0LjEuMS13Yy44LjAuMSJ9LCJ6b29tIjp7InMiOiJodHRwczpcL1wvMTI3LjAuMC4xXC9lX2NvbW1lcmNlX3Byb2plY3RcL3dvcmRwcmVzc1wvd3AtY29udGVudFwvcGx1Z2luc1wvd29vY29tbWVyY2VcL2Fzc2V0c1wvanNcL3pvb21cL2pxdWVyeS56b29tLm1pbi5qcyIsInYiOiIxLjcuMjEtd2MuOC4wLjEifX0sIndjX2pzIjp7InBob3Rvc3dpcGUiOnsicyI6Imh0dHBzOlwvXC8xMjcuMC4wLjFcL2VfY29tbWVyY2VfcHJvamVjdFwvd29yZHByZXNzXC93cC1jb250ZW50XC9wbHVnaW5zXC93b29jb21tZXJjZVwvYXNzZXRzXC9qc1wvcGhvdG9zd2lwZVwvcGhvdG9zd2lwZS5taW4uanMiLCJ2IjoiNC4xLjEtd2MuOC4wLjEifX0sInNwYXJrbGluZ19jb2xvciI6IiNkY2FhMmUiLCJsbmciOnsiYWRkX3RvIjoiQWRkZWQgdG8gQ2FydCIsImtlZXBfc2hvcCI6IktlZXAgU2hvcHBpbmciLCJjaGVja291dCI6IkNoZWNrb3V0In0sImNoZWNrb3V0X3VybCI6Imh0dHBzOlwvXC8xMjcuMC4wLjFcL2VfY29tbWVyY2VfcHJvamVjdFwvd29yZHByZXNzXC8/cGFnZV9pZD04Iiwid2NfY3NzX3VybCI6Imh0dHBzOlwvXC8xMjcuMC4wLjFcL2VfY29tbWVyY2VfcHJvamVjdFwvd29yZHByZXNzXC93cC1jb250ZW50XC90aGVtZXNcL3RoZW1pZnktc2hvcHBlXC9zdHlsZXNcL3djXC9tb2R1bGVzXC8iLCJwbGFjZWhvbGRlciI6Imh0dHBzOlwvXC8xMjcuMC4wLjFcL2VfY29tbWVyY2VfcHJvamVjdFwvd29yZHByZXNzXC93cC1jb250ZW50XC91cGxvYWRzXC93b29jb21tZXJjZS1wbGFjZWhvbGRlci5wbmciLCJ3aXNobGlzdCI6eyJub19pdGVtcyI6IlRoZXJlIGlzIG5vIHdpc2hsaXN0IGl0ZW0uIiwiY29va2llIjoidGhlbWlmeV93aXNobGlzdCIsImV4cGlyYXRpb24iOjE2OTQ0OTM0OTYsImNvb2tpZV9wYXRoIjoiXC9lX2NvbW1lcmNlX3Byb2plY3RcL3dvcmRwcmVzc1wvIiwiZG9tYWluIjoiIn0sImFqYXhDYXJ0U2Vjb25kcyI6IjEwMDAifTsKdmFyIHRiTG9jYWxTY3JpcHQgPSB7ImJyZWFrcG9pbnRzIjp7InRhYmxldF9sYW5kc2NhcGUiOls3NjksMTAyNF0sInRhYmxldCI6WzYwMSw3NjhdLCJtb2JpbGUiOjYwMH0sInNjcm9sbEhpZ2hsaWdodCI6eyJzcGVlZCI6OTAwLjAxfSwiYWRkb25zIjp7InByb2R1Y3RzIjp7ImpzIjoiaHR0cHM6Ly8xMjcuMC4wLjEvZV9jb21tZXJjZV9wcm9qZWN0L3dvcmRwcmVzcy93cC1jb250ZW50L3BsdWdpbnMvYnVpbGRlci13b29jb21tZXJjZS9hc3NldHMvc2NyaXB0cyIsInZlciI6IjMuMC4xIn19fTsKdmFyIHRoZW1pZnlfdmFycyA9IHsibWVudV9wb2ludCI6IjExMDAiLCJ3cCI6IjYuMyIsImFqYXhfdXJsIjoiaHR0cHM6Ly8xMjcuMC4wLjEvZV9jb21tZXJjZV9wcm9qZWN0L3dvcmRwcmVzcy93cC1hZG1pbi9hZG1pbi1hamF4LnBocCIsIm1lbnVfdG9vbHRpcHMiOltdLCJwbHVnaW5fdXJsIjoiaHR0cHM6Ly8xMjcuMC4wLjEvZV9jb21tZXJjZV9wcm9qZWN0L3dvcmRwcmVzcy93cC1jb250ZW50L3BsdWdpbnMiLCJ0aGVtZV92IjoiNy4yLjUiLCJlbWFpbFN1YiI6IkNoZWNrIHRoaXMgb3V0ISIsIm5vcCI6IkNoZWNrIHRoaXMgb3V0ISIsImxpZ2h0Ym94Ijp7ImkxOG4iOnsidENvdW50ZXIiOiIlY3VyciUgb2YgJXRvdGFsJSJ9fSwic192IjoiNS4zLjkiLCJ3Y192ZXJzaW9uIjoiOC4wLjEiLCJ3Y19qcyI6eyJqcy1jb29raWUiOiJodHRwczovLzEyNy4wLjAuMS9lX2NvbW1lcmNlX3Byb2plY3Qvd29yZHByZXNzL3dwLWNvbnRlbnQvcGx1Z2lucy93b29jb21tZXJjZS9hc3NldHMvanMvanMtY29va2llL2pzLmNvb2tpZS5taW4uanM/dmVyPTIuMS40LXdjLjguMC4xIiwid2MtYWRkLXRvLWNhcnQiOiJodHRwczovLzEyNy4wLjAuMS9lX2NvbW1lcmNlX3Byb2plY3Qvd29yZHByZXNzL3dwLWNvbnRlbnQvcGx1Z2lucy93b29jb21tZXJjZS9hc3NldHMvanMvZnJvbnRlbmQvYWRkLXRvLWNhcnQubWluLmpzIiwid2MtYWRkLXRvLWNhcnQtdmFyaWF0aW9uIjoiaHR0cHM6Ly8xMjcuMC4wLjEvZV9jb21tZXJjZV9wcm9qZWN0L3dvcmRwcmVzcy93cC1jb250ZW50L3BsdWdpbnMvd29vY29tbWVyY2UvYXNzZXRzL2pzL2Zyb250ZW5kL2FkZC10by1jYXJ0LXZhcmlhdGlvbi5taW4uanMiLCJ3Yy1jYXJ0LWZyYWdtZW50cyI6Imh0dHBzOi8vMTI3LjAuMC4xL2VfY29tbWVyY2VfcHJvamVjdC93b3JkcHJlc3Mvd3AtY29udGVudC9wbHVnaW5zL3dvb2NvbW1lcmNlL2Fzc2V0cy9qcy9mcm9udGVuZC9jYXJ0LWZyYWdtZW50cy5taW4uanMiLCJ3b29jb21tZXJjZSI6Imh0dHBzOi8vMTI3LjAuMC4xL2VfY29tbWVyY2VfcHJvamVjdC93b3JkcHJlc3Mvd3AtY29udGVudC9wbHVnaW5zL3dvb2NvbW1lcmNlL2Fzc2V0cy9qcy9mcm9udGVuZC93b29jb21tZXJjZS5taW4uanMiLCJ3Yy1zaW5nbGUtcHJvZHVjdCI6Imh0dHBzOi8vMTI3LjAuMC4xL2VfY29tbWVyY2VfcHJvamVjdC93b3JkcHJlc3Mvd3AtY29udGVudC9wbHVnaW5zL3dvb2NvbW1lcmNlL2Fzc2V0cy9qcy9mcm9udGVuZC9zaW5nbGUtcHJvZHVjdC5taW4uanMifSwicGhvdG9zd2lwZSI6eyJtYWluIjoiaHR0cHM6Ly8xMjcuMC4wLjEvZV9jb21tZXJjZV9wcm9qZWN0L3dvcmRwcmVzcy93cC1jb250ZW50L3BsdWdpbnMvd29vY29tbWVyY2UvYXNzZXRzL2Nzcy9waG90b3N3aXBlL3Bob3Rvc3dpcGUubWluLmNzcyIsInNraW4iOiJodHRwczovLzEyNy4wLjAuMS9lX2NvbW1lcmNlX3Byb2plY3Qvd29yZHByZXNzL3dwLWNvbnRlbnQvcGx1Z2lucy93b29jb21tZXJjZS9hc3NldHMvY3NzL3Bob3Rvc3dpcGUvZGVmYXVsdC1za2luL2RlZmF1bHQtc2tpbi5taW4uY3NzIn0sImRvbmUiOnsidGJfdGV4dCI6dHJ1ZSwidGJfc3R5bGUiOnRydWUsInRmX3NlYXJjaF9mb3JtIjp0cnVlLCJ0Zl9tZWdhbWVudSI6dHJ1ZSwidGJfY292ZXIiOnRydWUsInRiX2J1dHRvbnMiOnRydWUsInRiX2NvbG9yIjp0cnVlLCJ0Yl9wcm9kdWN0cyI6dHJ1ZSwidGZfZ3JpZF90aGVtZV9ncmlkMyI6dHJ1ZSwidGZfZ3JpZF9ncmlkMyI6dHJ1ZSwidGJfcHJvZHVjdC1jYXRlZ29yaWVzIjp0cnVlLCJ0Zl9ncmlkX3RoZW1lX2dyaWQ1Ijp0cnVlLCJ0Zl9ncmlkX2dyaWQ1Ijp0cnVlLCJ0Zl90aGVtZV9zb2NpYWxfbGlua3MiOnRydWV9fTt2YXIgd2NfYWRkX3RvX2NhcnRfcGFyYW1zID0geyJhamF4X3VybCI6IlwvZV9jb21tZXJjZV9wcm9qZWN0XC93b3JkcHJlc3NcL3dwLWFkbWluXC9hZG1pbi1hamF4LnBocCIsIndjX2FqYXhfdXJsIjoiXC9lX2NvbW1lcmNlX3Byb2plY3RcL3dvcmRwcmVzc1wvP3djLWFqYXg9JSVlbmRwb2ludCUlIiwiaTE4bl92aWV3X2NhcnQiOiJWaWV3IGJhc2tldCIsImNhcnRfdXJsIjoiaHR0cHM6XC9cLzEyNy4wLjAuMVwvZV9jb21tZXJjZV9wcm9qZWN0XC93b3JkcHJlc3NcLz9wYWdlX2lkPTciLCJpc19jYXJ0IjoiIiwiY2FydF9yZWRpcmVjdF9hZnRlcl9hZGQiOiJubyJ9O3ZhciB3Y19hZGRfdG9fY2FydF92YXJpYXRpb25fcGFyYW1zID0geyJ3Y19hamF4X3VybCI6IlwvZV9jb21tZXJjZV9wcm9qZWN0XC93b3JkcHJlc3NcLz93Yy1hamF4PSUlZW5kcG9pbnQlJSIsImkxOG5fbm9fbWF0Y2hpbmdfdmFyaWF0aW9uc190ZXh0IjoiU29ycnksIG5vIHByb2R1Y3RzIG1hdGNoZWQgeW91ciBzZWxlY3Rpb24uIFBsZWFzZSBjaG9vc2UgYSBkaWZmZXJlbnQgY29tYmluYXRpb24uIiwiaTE4bl9tYWtlX2Ffc2VsZWN0aW9uX3RleHQiOiJQbGVhc2Ugc2VsZWN0IHNvbWUgcHJvZHVjdCBvcHRpb25zIGJlZm9yZSBhZGRpbmcgdGhpcyBwcm9kdWN0IHRvIHlvdXIgYmFza2V0LiIsImkxOG5fdW5hdmFpbGFibGVfdGV4dCI6IlNvcnJ5LCB0aGlzIHByb2R1Y3QgaXMgdW5hdmFpbGFibGUuIFBsZWFzZSBjaG9vc2UgYSBkaWZmZXJlbnQgY29tYmluYXRpb24uIn07dmFyIHdjX2NhcnRfZnJhZ21lbnRzX3BhcmFtcyA9IHsiYWpheF91cmwiOiJcL2VfY29tbWVyY2VfcHJvamVjdFwvd29yZHByZXNzXC93cC1hZG1pblwvYWRtaW4tYWpheC5waHAiLCJ3Y19hamF4X3VybCI6IlwvZV9jb21tZXJjZV9wcm9qZWN0XC93b3JkcHJlc3NcLz93Yy1hamF4PSUlZW5kcG9pbnQlJSIsImNhcnRfaGFzaF9rZXkiOiJ3Y19jYXJ0X2hhc2hfZGIxZDQ2ZWQ5NjFjODFmNGMyMGYxMWZhMTEzN2RkMDYiLCJmcmFnbWVudF9uYW1lIjoid2NfZnJhZ21lbnRzX2RiMWQ0NmVkOTYxYzgxZjRjMjBmMTFmYTExMzdkZDA2IiwicmVxdWVzdF90aW1lb3V0IjoiNTAwMCJ9O3ZhciB3b29jb21tZXJjZV9wYXJhbXMgPSB7ImFqYXhfdXJsIjoiXC9lX2NvbW1lcmNlX3Byb2plY3RcL3dvcmRwcmVzc1wvd3AtYWRtaW5cL2FkbWluLWFqYXgucGhwIiwid2NfYWpheF91cmwiOiJcL2VfY29tbWVyY2VfcHJvamVjdFwvd29yZHByZXNzXC8/d2MtYWpheD0lJWVuZHBvaW50JSUifTt2YXIgd2Nfc2luZ2xlX3Byb2R1Y3RfcGFyYW1zID0geyJpMThuX3JlcXVpcmVkX3JhdGluZ190ZXh0IjoiUGxlYXNlIHNlbGVjdCBhIHJhdGluZyIsInJldmlld19yYXRpbmdfcmVxdWlyZWQiOiJ5ZXMiLCJmbGV4c2xpZGVyIjp7InJ0bCI6ZmFsc2UsImFuaW1hdGlvbiI6InNsaWRlIiwic21vb3RoSGVpZ2h0Ijp0cnVlLCJkaXJlY3Rpb25OYXYiOmZhbHNlLCJjb250cm9sTmF2IjoidGh1bWJuYWlscyIsInNsaWRlc2hvdyI6ZmFsc2UsImFuaW1hdGlvblNwZWVkIjo1MDAsImFuaW1hdGlvbkxvb3AiOmZhbHNlLCJhbGxvd09uZVNsaWRlIjpmYWxzZX0sInpvb21fZW5hYmxlZCI6IjEiLCJ6b29tX29wdGlvbnMiOltdLCJwaG90b3N3aXBlX2VuYWJsZWQiOiIxIiwicGhvdG9zd2lwZV9vcHRpb25zIjp7InNoYXJlRWwiOmZhbHNlLCJjbG9zZU9uU2Nyb2xsIjpmYWxzZSwiaGlzdG9yeSI6ZmFsc2UsImhpZGVBbmltYXRpb25EdXJhdGlvbiI6MCwic2hvd0FuaW1hdGlvbkR1cmF0aW9uIjowfSwiZmxleHNsaWRlcl9lbmFibGVkIjoiMSJ9Ow=="></script>
                <!--/noptimize-->
                <!--/noindex-->
                <!--googleon:all-->
                <script defer="defer" data-v="7.2.3" data-pl-href="https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/fake.css" data-no-optimize="1" data-noptimize="1" src='https://127.0.0.1/e_commerce_project/wordpress/wp-content/themes/themify-shoppe/themify/js/main.js?ver=7.2.3' id='themify-main-script-js'></script>
<script id='wapf-frontend-js-js-extra'>
var wapf_config = {"page_type":"other"};
</script>
<script src='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/advanced-product-fields-for-woocommerce/assets/js/frontend.min.js?ver=1.6.3' id='wapf-frontend-js-js'></script>
<script defer="defer" src='https://127.0.0.1/e_commerce_project/wordpress/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.8.0.1' id='jquery-blockui-js'></script>


<!-- SCHEMA BEGIN --><script type="application/ld+json">[{"@context":"https:\/\/schema.org","@type":"WebSite","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress","potentialAction":{"@type":"SearchAction","target":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress?s={search_term_string}","query-input":"required name=search_term_string"}},{"@context":"https:\/\/schema.org","@type":"WebPage","mainEntityOfPage":{"@type":"WebPage","@id":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/"},"headline":"Home","datePublished":"2023-08-11T17:32:16+05:30","dateModified":"2023-08-12T23:02:28+05:30","description":""},{"@context":"https:\/\/schema.org","@type":"Product","name":"Leggings","description":"","sku":"","brand":"","offers":{"@type":"Offer","price":"79","priceCurrency":"USD","priceValidUntil":"","availability":"https:\/\/schema.org\/InStock","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/product\/leggings\/"},"image":{"@type":"ImageObject","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/wp-content\/uploads\/2023\/08\/Category-Jungle-Leggings-80.jpg","width":1000,"height":1000}},{"@context":"https:\/\/schema.org","@type":"Product","name":"Bottles","description":"","sku":"","brand":"","offers":{"@type":"Offer","price":"55","priceCurrency":"USD","priceValidUntil":"","availability":"https:\/\/schema.org\/InStock","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/product\/bottles\/"},"image":{"@type":"ImageObject","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/wp-content\/uploads\/2023\/08\/Silver-Bottle.png","width":640,"height":640}},{"@context":"https:\/\/schema.org","@type":"Product","name":"Rings","description":"","sku":"","brand":"","offers":{"@type":"Offer","price":"79","priceCurrency":"USD","priceValidUntil":"","availability":"https:\/\/schema.org\/InStock","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/product\/rings\/"},"image":{"@type":"ImageObject","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/wp-content\/uploads\/2023\/08\/r4.jpg","width":474,"height":385}},{"@context":"https:\/\/schema.org","@type":"Product","name":"Simple products","description":"","sku":"","brand":"","offers":{"@type":"Offer","price":"450","priceCurrency":"USD","priceValidUntil":"","availability":"https:\/\/schema.org\/InStock","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/product\/simple-products-3\/"},"image":{"@type":"ImageObject","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/wp-content\/uploads\/2023\/08\/h4.jpg","width":474,"height":474}},{"@context":"https:\/\/schema.org","@type":"Product","name":"Variable products","description":"","sku":"","brand":"","offers":{"@type":"Offer","price":"99","priceCurrency":"USD","priceValidUntil":"","availability":"https:\/\/schema.org\/InStock","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/product\/variable-products\/"},"image":{"@type":"ImageObject","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/wp-content\/uploads\/2023\/08\/5-variant-braided-loop-for-apple-watch-strap-44mm-40mm-45mm-41mm-42mm-38mm-49mm-elastic-solo-bracelet-iwatch-series-7-se-3-6-ultra-8-band.png","width":640,"height":640}},{"@context":"https:\/\/schema.org","@type":"Product","name":"Simple products","description":"","sku":"","brand":"","offers":{"@type":"Offer","price":"149","priceCurrency":"USD","priceValidUntil":"","availability":"https:\/\/schema.org\/InStock","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/product\/backpack\/"},"image":{"@type":"ImageObject","url":"https:\/\/127.0.0.1\/e_commerce_project\/wordpress\/wp-content\/uploads\/2023\/08\/1.jpg","width":474,"height":474}}]</script><!-- /SCHEMA END -->	</body>
</html>

<!-- Cache served by breeze CACHE - Last modified: Sun, 13 Aug 2023 04:38:17 GMT -->
";s:7:"headers";a:3:{i:0;a:2:{s:4:"name";s:14:"Content-Length";s:5:"value";i:142556;}i:1;a:2:{s:4:"name";s:12:"Content-Type";s:5:"value";s:24:"text/html; charset=utf-8";}i:2;a:2:{s:4:"name";s:13:"Last-Modified";s:5:"value";s:29:"Sun, 13 Aug 2023 04:38:17 GMT";}}}