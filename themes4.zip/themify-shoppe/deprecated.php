<?php
global $themify;
$themify->hide_product_image='';
function themify_is_product_search(){}
function themify_hide_social_share(){}
function themify_hide_quick_look(){}