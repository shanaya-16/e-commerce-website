<?php return array(
        'shop-landing-1.zip',
        'shop-landing-2.zip',
        'shop-landing-3.zip',
        'shop-landing-4.zip',
        'shop-landing-5.zip',
        'shop-landing-6.zip',
        'shop-landing-7.zip',
        'shop-landing-8.zip',
        'shop-landing-9.zip',
        'shop-landing-10.zip',
        'shop-landing-11.zip',
        'shop-landing-12.zip',
        'shop-landing-13.zip',
        'shop-landing-14.zip'
);