<?php

defined( 'ABSPATH' ) || exit;

if(!defined('TF_CACHE_FW')){
    define('TF_CACHE_FW','#TF_CACHE_FW#');
}
if(!defined('TF_CACHE_TIME')){
    define('TF_CACHE_TIME','#TF_CACHE_TIME#');
}
if(!defined('TF_CACHE_RULES')){
    define('TF_CACHE_RULES','#TF_CACHE_RULES#');
}
if(!defined('TF_CACHE_IGNORE')){
    define('TF_CACHE_IGNORE','#TF_CACHE_IGNORE#');
}